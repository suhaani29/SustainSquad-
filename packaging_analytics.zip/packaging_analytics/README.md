# Packaging analytics

Brand-agnostic, vendor-agnostic pipeline for packaging data: ingest, normalize, validate, score digital readiness, recommend, report.
**All variation lives in `config/*.yaml`, validated at load. No brand, vendor or category name appears in `src/`.**

```mermaid
flowchart LR
  raw[data/raw per brand+vendor] --> ing[ingest adapters<br/>csv xlsx json api pdf_table]
  ing --> norm[normalize<br/>aliases, units, FX, code crosswalk]
  norm --> staged[(data/staged)]
  norm --> rej[(data/rejects<br/>reason codes)]
  staged --> val[validate<br/>pydantic schema + rules engine]
  val --> surv[survivorship<br/>per brand order]
  surv --> cur[(data/curated)]
  cur --> ana[quality, gaps, readiness,<br/>cost+sustainability, recommend]
  ana --> rep[reports/ HTML+Excel+CSV<br/>per brand, vendor, benchmark]
  ana --> web[web/ 3D page]
```

## Run
```bash
pip install -e .[dev]
python scripts/generate_sample_data.py --out data/raw --seed 7   # 3 brands x 3 vendors, mixed formats/units/currencies
pipeline run --stage report                    # all brands, all vendors
pipeline run --brand lumen --vendor nordpack --stage normalize   # stages: normalize | validate | report
pytest
python scripts/export_web_bundle.py && python scripts/build_web.py   # refresh web/packaging-data-towers.html
```
Runs are idempotent and deterministic: `as_of` is `--as-of`, else env `PIPELINE_AS_OF`, else the rate-table date.
Secrets: none in code or config. The `api` adapter reads its endpoint from the env var named in `source.url` and a token from `VENDOR_<ID>_TOKEN`.

## Onboard a new vendor (YAML only)
1. Copy `config/vendors/nordpack.yaml` to `config/vendors/<vendor_id>.yaml` (`vendor_id` must equal the file name).
2. Set `source` (format, `path_pattern`, encoding, delimiter, decimal/thousands, date format, sheet/header row or JSON `records_path`).
3. Set `units` (mm/cm/in/m, g/kg/oz/lb), `currency`, `null_tokens`, `bool_true/false`, `capabilities`, `update_cadence_days`.
4. Map `columns`: canonical field -> list of header aliases (dotted paths for nested JSON; `dimensions_combined` for "L x W x H").
5. Add `code_maps` (vendor code -> canonical code) for category, packaging level, material, recyclability.
6. Add the vendor to a brand's `vendors:` list. Unmapped headers are kept in `extras`; unmapped codes land in the review queue.

## Onboard a new brand (YAML only)
Copy `config/brands/aurora.yaml`: `brand_id`, `reporting_currency`, `default_region`, `vendors`, `report_units`, `taxonomy_labels`, `thresholds` (fuzzy auto-apply, freshness, consolidation spread, reduction factor), `required_fields`, `survivorship` order (`preferred_vendor`, `most_recent`, `highest_completeness`), `preferred_vendors`, `readiness_weights` overrides, `report_template`.

## Add or override a rule (YAML only)
Add to `config/rules/<category>.yaml` or `_common.yaml`: `rule_id`, `rule_version`, `scope` (category / brand / vendor / region), `severity` (error|warn|info), `when`, `assert` (ops: `< <= > >= == != in not_in required not_null between regex contains_any contains_all`; fields incl. derived `volume_cm3`, `density_g_cm3`, `material_family`), `message`, `fix_hint`, `enabled`.
Most specific scope wins per `rule_id` (vendor 8 > brand 4 > region 2 > category 1); same scope: higher version wins; `enabled: false` in a more specific rule switches it off there.

## Guarantees (each has a test)
| Requirement | Where |
|---|---|
| 4th vendor + 4th brand = YAML only | `tests/test_config_only_onboarding.py` |
| Rule precedence, rules in isolation | `tests/test_rules.py` |
| Unit and FX conversion | `tests/test_units_currency.py` |
| Cross-brand isolation, aggregate-only benchmark | `tests/test_isolation.py` |
| Survivorship, rejects with reason codes, lineage of every violation, idempotence, readiness reproducible | `tests/test_pipeline.py` |

## Layout
`config/` canonical_schema, taxonomy, rates, readiness, recommendations, presentation, brands/, vendors/, rules/ · `src/` ingest, normalize, validate, quality, readiness, recommend, report · `data/{raw,staged,curated,rejects}` · `reports/` · `web/` 3D page built from `bundle.json`.

## Assumptions
- Canonical units are mm and g; reports convert to each brand's `report_units`. Unit costs are converted to the brand's reporting currency using the as-of rate table.
- Rules run on every schema-valid vendor record before survivorship, so each violation points at its own source row.
- Digital readiness dimensions are derived from vendor config and ingest results; the formula is Σ(weight x score) / Σ(weight).
- `pdf_table` needs `pdfplumber` (optional); `api` is exercised offline by pointing it at a local JSON file.
