"""One brand's BrandData -> every analysis module's output. The only entry point reports use."""
from __future__ import annotations

from dataclasses import replace
from typing import Any

from src.config import Config
from src.models import BrandData
from src.quality.metrics import cost_sustainability, gap_analysis, inventory, quality_metrics
from src.readiness.score import readiness
from src.recommend.engine import recommend


def analyze_brand(cfg: Config, bd: BrandData) -> dict[str, Any]:
    q = quality_metrics(cfg, bd)
    gaps = gap_analysis(cfg, bd)
    inv = inventory(cfg, bd)
    cs = cost_sustainability(cfg, bd)
    rd = readiness(cfg, bd)
    metrics = {"quality": q, "readiness": rd, "sustainability": cs["sustainability"]}
    tables = {"rejects": bd.rejects, "violations": bd.violations, "conflicts": bd.conflicts,
              "consolidation": cs["consolidation"], "reduction": cs["reduction"], "curated": bd.curated,
              "review": bd.review}
    recs = recommend(cfg, metrics, tables)
    out = {"brand_id": bd.brand_id, "as_of": bd.as_of.isoformat(), "quality": q, "gaps": gaps, "inventory": inv,
           "cost": cs, "readiness": rd, "recommendations": recs, "tables": tables,
           "weights": cfg.readiness_weights(bd.brand_id)}
    assert_single_brand(out)
    return out


def assert_single_brand(analysis: dict[str, Any]) -> None:
    """Isolation guard: nothing from another brand may sit in a per-brand analysis."""
    b = analysis["brand_id"]
    for name, rows in analysis["tables"].items():
        for r in rows:
            if r.get("brand_id", b) != b:
                raise AssertionError(f"brand leakage: {name} row for {r.get('brand_id')} in {b} analysis")


def vendor_view(bd: BrandData, vendor_id: str) -> BrandData:
    """Same brand, one vendor's data only (no survivorship across vendors)."""
    f = lambda rows: [r for r in rows if r["vendor_id"] == vendor_id]  # noqa: E731
    cand = f(bd.candidates)
    return replace(bd, candidates=cand, curated=cand, rejects=f(bd.rejects), review=f(bd.review),
                   violations=f(bd.violations), conflicts=[], survivorship=[],
                   vendor_stats=[v for v in bd.vendor_stats if v.vendor_id == vendor_id])
