"""Quality, gap and inventory metrics for ONE brand. Takes BrandData only, so brands can never mix."""
from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from datetime import timedelta
from typing import Any

from src.config import Config
from src.models import BrandData

NON_DATA = {"brand_id", "vendor_id"}


def _filled(v: Any) -> bool:
    return v not in (None, "", [])


def _share(n: float, d: float) -> float:
    return round(n / d, 4) if d else 0.0


def quality_metrics(cfg: Config, bd: BrandData) -> dict[str, Any]:
    brand = cfg.brands[bd.brand_id]
    fields = [f for f in cfg.schema_.fields if f not in NON_DATA]
    cur, cand = bd.curated, bd.candidates
    by_field = {f: _share(sum(_filled(r.get(f)) for r in cur), len(cur)) for f in fields}
    by_vendor: dict[str, Any] = {}
    for vs in bd.vendor_stats:
        vr = [r for r in cand if r["vendor_id"] == vs.vendor_id]
        dups = sum(1 for x in bd.rejects if x["vendor_id"] == vs.vendor_id and x["reason_code"] == "DUPLICATE_IN_SOURCE")
        err_rows = {v["source_row"] for v in bd.violations if v["vendor_id"] == vs.vendor_id and v["severity"] == "error"}
        by_vendor[vs.vendor_id] = {
            "rows": vs.n_raw,
            "completeness": _share(sum(_filled(r.get(f)) for r in vr for f in fields), len(vr) * len(fields)),
            "validity": _share(len(vr), vs.n_raw),
            "rule_pass_rate": _share(len(vr) - len(err_rows), len(vr)),
            "uniqueness": _share(vs.n_raw - dups, vs.n_raw),
            "by_field": {f: _share(sum(_filled(r.get(f)) for r in vr), len(vr)) for f in fields},
        }
    multi = [s for s in bd.survivorship if len(s["candidates"]) > 1]
    conflicted = {c["sku"] for c in bd.conflicts}
    cutoff = bd.as_of - timedelta(days=brand.thresholds.freshness_days)
    fresh = sum(1 for r in cur if r.get("effective_from") and r["effective_from"] >= cutoff)
    total_raw = sum(v.n_raw for v in bd.vendor_stats)
    dups_all = sum(1 for x in bd.rejects if x["reason_code"] == "DUPLICATE_IN_SOURCE")
    return {
        "completeness": {"overall": _share(sum(_filled(r.get(f)) for r in cur for f in fields), len(cur) * len(fields)),
                         "by_field": by_field},
        "by_vendor": by_vendor,
        "validity": _share(len(cand), total_raw),
        "uniqueness": _share(total_raw - dups_all, total_raw),
        "consistency": _share(len(multi) - len(conflicted & {s["sku"] for s in multi}), len(multi)) if multi else 1.0,
        "timeliness": _share(fresh, len(cur)),
        "counts": {"raw_rows": total_raw, "candidates": len(cand), "curated_skus": len(cur),
                   "multi_source_skus": len(multi), "rejects": len(bd.rejects), "review_queue": len(bd.review),
                   "violations": len(bd.violations)},
    }


def gap_analysis(cfg: Config, bd: BrandData) -> dict[str, Any]:
    fields = [f for f in cfg.schema_.fields if f not in NON_DATA]
    cur = bd.curated
    missing = [{"field": f, "missing": n, "share": _share(n, len(cur)),
                "vendors_missing": sorted({r["vendor_id"] for r in bd.candidates if not _filled(r.get(f))})}
               for f in fields if (n := sum(not _filled(r.get(f)) for r in cur))]
    missing.sort(key=lambda x: -x["missing"])
    manual = []
    brand_cols = set(cfg.brands[bd.brand_id].manual_indicator_columns)
    for vs in bd.vendor_stats:
        cols = set(cfg.vendors[vs.vendor_id].manual_indicator_columns) | brand_cols
        for c in sorted(cols):
            n = sum(1 for r in bd.candidates if r["vendor_id"] == vs.vendor_id and _filled(r["extras"].get(c)))
            manual.append({"vendor_id": vs.vendor_id, "column": c, "rows_with_notes": n,
                           "share": _share(n, vs.n_raw), "automated_ingestion": cfg.vendors[vs.vendor_id].capabilities.automated_ingestion})
    codes = Counter(x["reason_code"] for x in bd.rejects if x["reason_code"].startswith("UNMAPPED_"))
    return {"missing_fields": missing, "manual_indicators": manual, "unmapped_codes": dict(codes),
            "conflicts": len(bd.conflicts), "reject_reasons": dict(Counter(x["reason_code"] for x in bd.rejects)),
            "violations_by_rule": dict(Counter(f'{v["rule_id"]}:{v["severity"]}' for v in bd.violations))}


def inventory(cfg: Config, bd: BrandData) -> list[dict[str, Any]]:
    skus = {r["sku"] for r in bd.curated}
    out = []
    for vs in bd.vendor_stats:
        v = cfg.vendors[vs.vendor_id]
        vr = [r for r in bd.candidates if r["vendor_id"] == vs.vendor_id]
        dates = [r["effective_from"] for r in vr if r.get("effective_from")]
        ages = [(bd.as_of - d).days for d in dates]
        out.append({"vendor_id": vs.vendor_id, "name": v.display_name, "owner": v.owner, "format": v.source.format,
                    "source_file": vs.source_file, "rows": vs.n_raw, "valid_rows": len(vr),
                    "coverage": _share(len({r["sku"] for r in vr}), len(skus)),
                    "newest": max(dates).isoformat() if dates else None,
                    "median_age_days": int(statistics.median(ages)) if ages else None,
                    "cadence_days": v.update_cadence_days,
                    "api": v.capabilities.api, "edi": v.capabilities.edi, "sftp": v.capabilities.sftp,
                    "automated": v.capabilities.automated_ingestion})
    return out


def cost_sustainability(cfg: Config, bd: BrandData) -> dict[str, Any]:
    th = cfg.brands[bd.brand_id].thresholds
    cand = bd.candidates
    grp: dict[tuple[str, str], list[float]] = defaultdict(list)
    for r in cand:
        if r.get("unit_cost") is not None:
            grp[(r["material_type"], r["vendor_id"])].append(r["unit_cost"])
    cost_rows = [{"material_type": m, "vendor_id": v, "avg_unit_cost": round(statistics.mean(xs), 4), "n": len(xs)}
                 for (m, v), xs in sorted(grp.items())]
    consolidation = []
    for m in sorted({r["material_type"] for r in cost_rows}):
        rows = [r for r in cost_rows if r["material_type"] == m and r["n"] >= 2]
        if len({r["vendor_id"] for r in rows}) < 2:
            continue
        lo, hi = min(rows, key=lambda r: r["avg_unit_cost"]), max(rows, key=lambda r: r["avg_unit_cost"])
        spread = (hi["avg_unit_cost"] - lo["avg_unit_cost"]) / lo["avg_unit_cost"] * 100 if lo["avg_unit_cost"] else 0
        if spread >= th.consolidation_spread_pct:
            consolidation.append({"brand_id": bd.brand_id, "material_type": m, "cheapest_vendor": lo["vendor_id"],
                                  "cheapest_avg": lo["avg_unit_cost"], "priciest_vendor": hi["vendor_id"],
                                  "priciest_avg": hi["avg_unit_cost"], "spread_pct": round(spread, 1),
                                  "n_records": lo["n"] + hi["n"], "currency": cfg.brands[bd.brand_id].reporting_currency})
    cur = bd.curated
    rc = [r["recycled_content_pct"] for r in cur if r.get("recycled_content_pct") is not None]
    rec = [r["recyclability"] for r in cur if r.get("recyclability")]
    peers: dict[tuple, list[float]] = defaultdict(list)
    for r in cur:
        if r.get("weight_g"):
            peers[(r["product_category"], r["packaging_level"])].append(r["weight_g"])
    reduction = []
    for r in cur:
        g = peers.get((r["product_category"], r["packaging_level"]), [])
        if r.get("weight_g") and len(g) >= 3:
            med = statistics.median(g)
            if r["weight_g"] > th.reduction_factor * med:
                reduction.append({"brand_id": bd.brand_id, "vendor_id": r["vendor_id"], "sku": r["sku"],
                                  "source_file": r["source_file"], "source_row": r["source_row"],
                                  "weight_g": r["weight_g"], "peer_median_g": round(med, 3),
                                  "ratio": round(r["weight_g"] / med, 2)})
    mat: dict[str, Any] = {}
    for r in cur:
        m = mat.setdefault(r["material_type"], {"n": 0, "rc": [], "rec": []})
        m["n"] += 1
        if r.get("recycled_content_pct") is not None: m["rc"].append(r["recycled_content_pct"])
        if r.get("recyclability"): m["rec"].append(r["recyclability"])
    return {
        "cost_by_material_vendor": cost_rows, "consolidation": consolidation, "reduction": reduction,
        "sustainability": {
            "recycled_content_avg": round(statistics.mean(rc), 2) if rc else None,
            "recyclable_share": _share(rec.count("recyclable"), len(rec)),
            "conditional_share": _share(rec.count("conditionally_recyclable"), len(rec)),
            "not_recyclable_share": _share(rec.count("not_recyclable"), len(rec)),
            "by_material": {m: {"n": v["n"], "recycled_avg": round(statistics.mean(v["rc"]), 1) if v["rc"] else None,
                                "not_recyclable": v["rec"].count("not_recyclable")} for m, v in sorted(mat.items())}},
    }
