"""Row model generated from canonical_schema.yaml (pydantic). Adding a field = YAML only."""
from __future__ import annotations

from datetime import date
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field, ValidationError, create_model

from src.config import CanonicalSchema, Config

_PY = {"str": str, "float": float, "int": int, "bool": bool, "date": date, "list": list[str],
       "enum": str, "enum_taxonomy": str}


def build_row_model(schema: CanonicalSchema) -> type[BaseModel]:
    fields: dict[str, Any] = {}
    for name, fd in schema.fields.items():
        kw: dict[str, Any] = {}
        if fd.min is not None:
            kw["ge"] = fd.min
        if fd.max is not None:
            kw["le"] = fd.max
        typ = _PY[fd.type] if fd.required else Optional[_PY[fd.type]]
        fields[name] = (typ, Field(... if fd.required else None, **kw))
    return create_model("CanonicalRow", __config__=ConfigDict(extra="ignore"), **fields)


def schema_errors(model: type[BaseModel], rec: dict[str, Any]) -> list[dict[str, Any]]:
    """[{reason_code, field, detail}] - empty when the record is schema-valid."""
    try:
        model(**{k: v for k, v in rec.items() if v is not None})
        return []
    except ValidationError as e:
        out = []
        for err in e.errors():
            f = str(err["loc"][0])
            t = err["type"]
            code = ("MISSING_REQUIRED_FIELD" if t == "missing"
                    else "OUT_OF_RANGE" if t in ("greater_than_equal", "less_than_equal", "greater_than", "less_than")
                    else "INVALID_VALUE")
            out.append({"reason_code": code, "field": f, "detail": err["msg"]})
        return out


def validate_schema(cfg: Config, records: list[dict[str, Any]]) -> tuple[list[dict], list[dict]]:
    """Split into (valid, rejects). Rejects keep lineage and reason code."""
    model = build_row_model(cfg.schema_)
    ok, bad = [], []
    for r in records:
        errs = schema_errors(model, r)
        if not errs:
            ok.append(r)
            continue
        for e in errs:
            bad.append({"brand_id": r["brand_id"], "vendor_id": r["vendor_id"], "source_file": r["source_file"],
                        "source_row": r["source_row"], "stage": "validate", "reason_code": e["reason_code"],
                        "field": e["field"], "raw_value": None if r.get(e["field"]) is None else str(r.get(e["field"])),
                        "detail": e["detail"]})
    return ok, bad
