"""Operators and derived (virtual) fields the rules engine understands.
Nothing here knows about a brand, vendor or product category."""
from __future__ import annotations

from typing import Any

OPS = {"<", "<=", ">", ">=", "==", "!=", "in", "not_in", "required", "not_null", "is_null",
       "between", "regex", "contains_any", "contains_all"}
DERIVED_FIELDS = {"volume_cm3", "density_g_cm3", "material_family"}


def derived_value(name: str, rec: dict[str, Any], taxonomy: Any) -> Any:
    if name == "volume_cm3":
        dims = [rec.get("length_mm"), rec.get("width_mm"), rec.get("height_mm")]
        if any(d is None for d in dims):
            return None
        return dims[0] * dims[1] * dims[2] / 1000.0
    if name == "density_g_cm3":
        vol = derived_value("volume_cm3", rec, taxonomy)
        w = rec.get("weight_g")
        if vol is None or w is None or vol <= 0:
            return None
        return w / vol
    if name == "material_family":
        m = rec.get("material_type")
        mat = taxonomy.materials.get(m) if m else None
        return mat.family if mat else None
    raise KeyError(name)
