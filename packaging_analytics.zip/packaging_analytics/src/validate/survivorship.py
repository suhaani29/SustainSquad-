"""Reconcile the same SKU arriving from several vendors, strategy order from the brand config."""
from __future__ import annotations

from collections import defaultdict
from datetime import date
from typing import Any

from src.config import BrandCfg, CanonicalSchema

SYSTEM = {"brand_id", "vendor_id", "source_system", "source_file", "source_row", "ingested_at", "extras",
          "src_unit_cost", "src_currency", "fx_as_of"}


def completeness(rec: dict[str, Any], schema: CanonicalSchema) -> int:
    return sum(1 for f in schema.fields if rec.get(f) not in (None, "", []))


def _keyfn(strategy: str, brand: BrandCfg, schema: CanonicalSchema):
    if strategy == "preferred_vendor":
        pref = brand.preferred_vendors
        return lambda r: -(len(pref) - pref.index(r["vendor_id"]) if r["vendor_id"] in pref else 0)  # lower is better
    if strategy == "most_recent":
        return lambda r: -(r.get("effective_from") or date.min).toordinal()
    return lambda r: -completeness(r, schema)


def _within(a: float, b: float, tol: float) -> bool:
    return abs(a - b) <= tol * max(abs(a), abs(b))


def survive(cands: list[dict[str, Any]], brand: BrandCfg, schema: CanonicalSchema
            ) -> tuple[dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    """-> (curated record, survivorship info, field conflicts)."""
    pool, decided_by = list(cands), "single_source"
    if len(pool) > 1:
        decided_by = "vendor_id_tiebreak"
        for s in brand.survivorship:
            kf = _keyfn(s, brand, schema)
            best = min(kf(r) for r in pool)
            pool = [r for r in pool if kf(r) == best]
            if len(pool) == 1:
                decided_by = s
                break
    winner = min(pool, key=lambda r: r["vendor_id"])
    losers = sorted((r for r in cands if r is not winner), key=lambda r: r["vendor_id"])
    curated = dict(winner)
    filled: dict[str, str] = {}
    if brand.fill_nulls_from_losers:
        for f in schema.fields:
            if curated.get(f) in (None, "", []):
                for l in losers:
                    if l.get(f) not in (None, "", []):
                        curated[f] = l[f]
                        filled[f] = l["vendor_id"]
                        break
    conflicts = []
    for f, spec in schema.conflict_fields.items():
        vals = {r["vendor_id"]: r.get(f) for r in cands if r.get(f) is not None}
        if len(vals) < 2:
            continue
        tol = spec.get("tolerance", 0.0)
        items = list(vals.values())
        differ = any(not (_within(items[0], x, tol) if isinstance(x, (int, float)) and not isinstance(x, bool)
                         else x == items[0]) for x in items[1:])
        if differ:
            conflicts.append({"brand_id": winner["brand_id"], "sku": winner["sku"], "field": f,
                              "values": vals, "winner_vendor": winner["vendor_id"], "winner_value": winner.get(f)})
    info = {"brand_id": winner["brand_id"], "sku": winner["sku"], "winner_vendor": winner["vendor_id"],
            "candidates": sorted(r["vendor_id"] for r in cands), "decided_by": decided_by,
            "filled_from": filled,
            "lineage": [{"vendor_id": r["vendor_id"], "source_file": r["source_file"], "source_row": r["source_row"]}
                        for r in sorted(cands, key=lambda r: r["vendor_id"])]}
    curated["survivorship"] = info
    return curated, info, conflicts


def reconcile(records: list[dict[str, Any]], brand: BrandCfg, schema: CanonicalSchema
              ) -> tuple[list[dict], list[dict], list[dict]]:
    groups: dict[str, list[dict]] = defaultdict(list)
    for r in records:
        groups[r["sku"]].append(r)
    curated, infos, conflicts = [], [], []
    for sku in sorted(groups):
        c, i, cf = survive(groups[sku], brand, schema)
        curated.append(c); infos.append(i); conflicts += cf
    return curated, infos, conflicts
