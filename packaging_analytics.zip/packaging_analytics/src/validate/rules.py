"""Declarative rules engine. Pure functions: a rule + a record in, violations out.
No brand, vendor or category names appear here; scope comes from the rule's YAML."""
from __future__ import annotations

import re
from typing import Any

from src.config import BrandCfg, Config, RuleDef, Taxonomy
from src.validate.derived import DERIVED_FIELDS, derived_value

SPECIFICITY = {"vendor": 8, "brand": 4, "region": 2, "category": 1}


def apply_op(op: str, actual: Any, expected: Any) -> bool:
    """True when the assertion HOLDS. Callers skip null actuals except for presence ops."""
    if op == "required" or op == "not_null":
        return actual not in (None, "", [])
    if op == "is_null":
        return actual in (None, "", [])
    if op == "==":
        return actual == expected
    if op == "!=":
        return actual != expected
    if op == "<":
        return actual < expected
    if op == "<=":
        return actual <= expected
    if op == ">":
        return actual > expected
    if op == ">=":
        return actual >= expected
    if op == "in":
        return actual in expected
    if op == "not_in":
        return actual not in expected
    if op == "between":
        return expected[0] <= actual <= expected[1]
    if op == "regex":
        return re.search(str(expected), str(actual)) is not None
    if op == "contains_any":
        return bool(set(actual or []) & set(expected))
    if op == "contains_all":
        return set(expected) <= set(actual or [])
    raise ValueError(f"unknown op {op}")


PRESENCE_OPS = {"required", "not_null", "is_null", "contains_any", "contains_all"}


def field_value(name: str, rec: dict[str, Any], tax: Taxonomy) -> Any:
    return derived_value(name, rec, tax) if name in DERIVED_FIELDS else rec.get(name)


def _when_ok(when: dict[str, Any], rec: dict[str, Any], tax: Taxonomy) -> bool:
    for f, cond in when.items():
        v = field_value(f, rec, tax)
        if v is None:
            return False
        if isinstance(cond, dict):
            if not apply_op(cond["op"], v, cond.get("value")):
                return False
        elif isinstance(cond, list):
            if v not in cond:
                return False
        elif v != cond:
            return False
    return True


def in_scope(rule: RuleDef, category: str | None, brand: str, vendor: str, region: str | None) -> bool:
    ctx = {"category": category, "brand": brand, "vendor": vendor, "region": region}
    return all(vals is None or ctx[d] in vals for d, vals in rule.scope.model_dump().items())


def specificity(rule: RuleDef) -> int:
    return sum(w for d, w in SPECIFICITY.items() if getattr(rule.scope, d) is not None)


def select_rules(rules: list[RuleDef], category: str | None, brand: str, vendor: str, region: str | None
                 ) -> list[RuleDef]:
    """Most specific scope wins per rule_id; ties go to the higher rule_version. Disabled winners drop out."""
    best: dict[str, RuleDef] = {}
    for r in rules:
        if not in_scope(r, category, brand, vendor, region):
            continue
        cur = best.get(r.rule_id)
        if cur is None or (specificity(r), r.rule_version) > (specificity(cur), cur.rule_version):
            best[r.rule_id] = r
    return [r for r in best.values() if r.enabled]


def evaluate(rule: RuleDef, rec: dict[str, Any], tax: Taxonomy) -> dict[str, Any] | None:
    """Violation dict or None."""
    if not _when_ok(rule.when, rec, tax):
        return None
    failed = []
    for a in rule.assert_:
        actual = field_value(a.field, rec, tax)
        if actual is None and a.op not in PRESENCE_OPS:
            continue
        expected = field_value(a.ref, rec, tax) if a.ref else a.value
        if a.ref and expected is None:
            continue
        if not apply_op(a.op, actual, expected):
            failed.append({"field": a.field, "op": a.op, "expected": expected, "actual": actual})
    if not failed:
        return None
    return {"rule_id": rule.rule_id, "rule_version": rule.rule_version, "severity": rule.severity,
            "message": rule.message, "fix_hint": rule.fix_hint, "failed": failed,
            "fields": sorted({f["field"] for f in failed})}


def required_violations(cfg: Config, rec: dict[str, Any]) -> list[dict[str, Any]]:
    brand: BrandCfg = cfg.brands[rec["brand_id"]]
    rf = cfg.required_by_category.get(rec["product_category"])
    need: dict[str, str] = {f: (rf.severity if rf else "warn") for f in (rf.fields if rf else [])}
    for f in brand.required_fields:
        need.setdefault(f, "warn")
    out = []
    for f, sev in need.items():
        if rec.get(f) in (None, "", []):
            out.append({"rule_id": "REQUIRED_FIELD", "rule_version": 1, "severity": sev,
                        "message": f"Required field '{f}' is missing", "fix_hint": f"Obtain {f} from the vendor",
                        "failed": [{"field": f, "op": "required", "expected": True, "actual": None}], "fields": [f]})
    return out


def run_rules(cfg: Config, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Evaluate every record; each violation carries full lineage back to source file and row."""
    out = []
    cache: dict[tuple, list[RuleDef]] = {}
    for rec in records:
        k = (rec["product_category"], rec["brand_id"], rec["vendor_id"], rec.get("region"))
        if k not in cache:
            cache[k] = select_rules(cfg.rules, *k)
        viols = [v for r in cache[k] if (v := evaluate(r, rec, cfg.taxonomy))] + required_violations(cfg, rec)
        for v in viols:
            out.append({**v, "brand_id": rec["brand_id"], "vendor_id": rec["vendor_id"], "sku": rec["sku"],
                        "product_category": rec["product_category"], "source_file": rec["source_file"],
                        "source_row": rec["source_row"]})
    return out
