"""Digital readiness score 0-100: weighted mean of six dimensions. Pure function of config + BrandData."""
from __future__ import annotations

from typing import Any

from src.config import Config
from src.models import BrandData


def _cadence_score(days: int, cfg: Config) -> float:
    for row in cfg.readiness.cadence_scoring:
        if row.max_days is None or days <= row.max_days:
            return row.score
    return 0.0


def compute_dimensions(cfg: Config, bd: BrandData) -> dict[str, float]:
    stats = bd.vendor_stats
    total = sum(s.n_raw for s in stats) or 1

    def wavg(fn) -> float:
        return sum(fn(cfg.vendors[s.vendor_id]) * s.n_raw for s in stats) / total * 100

    bad_code_rows = {(x["vendor_id"], x["source_row"]) for x in bd.rejects if x["reason_code"].startswith("UNMAPPED_")}
    bad_code_rows |= {(x["vendor_id"], x["source_row"]) for x in bd.review}
    cand = bd.candidates
    traced = sum(1 for r in cand if r.get("source_file") and r.get("source_row") and r.get("effective_from"))
    return {
        "structured_format_pct": wavg(lambda v: 1.0 if v.capabilities.structured else 0.0),
        "standard_coding_pct": (1 - len(bad_code_rows) / total) * 100,
        "api_edi_availability": wavg(lambda v: 1.0 if (v.capabilities.api or v.capabilities.edi)
                                     else 0.5 if v.capabilities.sftp else 0.0),
        "update_cadence": sum(_cadence_score(cfg.vendors[s.vendor_id].update_cadence_days, cfg) * s.n_raw
                              for s in stats) / total,
        "automation_coverage": wavg(lambda v: 1.0 if v.capabilities.automated_ingestion else 0.0),
        "traceability": traced / len(cand) * 100 if cand else 0.0,
    }


def readiness(cfg: Config, bd: BrandData, weights: dict[str, float] | None = None) -> dict[str, Any]:
    """Weights default to config + brand override; pass `weights` to recompute (what-if)."""
    w = weights or cfg.readiness_weights(bd.brand_id)
    dims = compute_dimensions(cfg, bd)
    wsum = sum(w.values()) or 1.0
    score = sum(w[k] * dims[k] for k in dims) / wsum
    band = next(b.label for b in sorted(cfg.readiness.bands, key=lambda b: -b.min) if score >= b.min)
    return {"score": round(score, 1), "band": band,
            "dimensions": {k: {"score": round(dims[k], 1), "weight": w[k], "share": round(w[k] / wsum, 4),
                               "contribution": round(w[k] * dims[k] / wsum, 2),
                               "description": cfg.readiness.dimensions[k].description} for k in dims}}
