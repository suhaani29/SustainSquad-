"""Staged, idempotent pipeline: normalize -> validate -> report. Every stage rewrites its outputs."""
from __future__ import annotations

import csv
import json
import logging
import os
import shutil
from datetime import date
from pathlib import Path
from typing import Any

from src.config import Config, load_config
from src.ingest import get_adapter
from src.models import BrandData, VendorStat
from src.normalize.normalizer import normalize_table
from src.validate.rules import run_rules
from src.validate.schema_model import validate_schema
from src.validate.survivorship import reconcile

log = logging.getLogger(__name__)
STAGES = ["normalize", "validate", "report"]


def resolve_as_of(cfg: Config, as_of: date | None = None) -> date:
    if as_of:
        return as_of
    env = os.environ.get("PIPELINE_AS_OF")
    return date.fromisoformat(env) if env else cfg.rates.as_of


# ------------------------------------------------------------------ json io (dates round-trip)
def _dump(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, default=str, sort_keys=True, ensure_ascii=False), encoding="utf-8")


def _revive(cfg: Config, rec: dict[str, Any]) -> dict[str, Any]:
    for f, fd in cfg.schema_.fields.items():
        if fd.type == "date" and isinstance(rec.get(f), str):
            rec[f] = date.fromisoformat(rec[f])
    return rec


def write_csv(rows: list[dict[str, Any]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    cols: list[str] = []
    for r in rows:
        cols += [k for k in r if k not in cols]
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: json.dumps(v, default=str, sort_keys=True) if isinstance(v, (dict, list)) else v
                        for k, v in r.items()})


# ------------------------------------------------------------------ stages
def stage_normalize(cfg: Config, root: Path, brand_id: str, vendor_id: str, as_of: date) -> None:
    v = cfg.vendors[vendor_id]
    path = root / v.source.path_pattern.format(brand=brand_id)
    if not path.exists():
        log.warning("no source for %s/%s at %s", brand_id, vendor_id, path)
        return
    rel = str(path.relative_to(root))
    table = get_adapter(v.source.format).read(v, path, rel)
    res = normalize_table(cfg, brand_id, vendor_id, table, as_of)
    _dump({"n_raw": res.n_raw, "source_file": rel, "columns_unmapped": res.columns_unmapped,
           "columns_mapped": res.columns_mapped, "records": res.records, "rejects": res.rejects,
           "review": res.review}, root / "data/staged" / brand_id / f"{vendor_id}.json")


def _load_staged(cfg: Config, root: Path, brand_id: str) -> tuple[list, list, list, list[VendorStat]]:
    recs, rej, rev, stats = [], [], [], []
    for vid in cfg.brands[brand_id].vendors:
        p = root / "data/staged" / brand_id / f"{vid}.json"
        if not p.exists():
            continue
        d = json.loads(p.read_text(encoding="utf-8"))
        recs += [_revive(cfg, r) for r in d["records"]]
        rej += d["rejects"]; rev += d["review"]
        stats.append(VendorStat(vid, d["source_file"], d["n_raw"], d["columns_unmapped"]))
    return recs, rej, rev, stats


def stage_validate(cfg: Config, root: Path, brand_id: str, as_of: date) -> BrandData:
    recs, rejects, review, stats = _load_staged(cfg, root, brand_id)
    valid, bad = validate_schema(cfg, recs)
    rejects = rejects + bad
    violations = run_rules(cfg, valid)
    curated, surv, conflicts = reconcile(valid, cfg.brands[brand_id], cfg.schema_)
    bd = BrandData(brand_id, as_of, valid, curated, rejects, review, violations, conflicts, surv, stats)
    out = root / "data/curated" / brand_id
    shutil.rmtree(out, ignore_errors=True)
    write_csv([{k: v for k, v in r.items() if k != "survivorship"} | {"winner_lineage": r["survivorship"]["lineage"]}
               for r in curated], out / "curated.csv")
    write_csv(violations, out / "violations.csv")
    write_csv(review, out / "review_queue.csv")
    _dump(conflicts, out / "conflicts.json")
    _dump(surv, out / "survivorship.json")
    write_csv(rejects, root / "data/rejects" / brand_id / "rejects.csv")
    log.info("validate %s: %d valid, %d curated, %d rejects, %d violations, %d conflicts",
             brand_id, len(valid), len(curated), len(rejects), len(violations), len(conflicts))
    return bd


def run(config_dir: str | Path = "config", root: str | Path = ".", brands: list[str] | None = None,
        vendors: list[str] | None = None, stage: str = "report", as_of: date | None = None
        ) -> dict[str, BrandData]:
    root = Path(root)
    cfg = load_config(root / config_dir)
    as_of = resolve_as_of(cfg, as_of)
    brand_ids = brands or sorted(cfg.brands)
    for b in brand_ids:
        if b not in cfg.brands:
            raise SystemExit(f"unknown brand '{b}'. Known: {sorted(cfg.brands)}")
    for v in vendors or []:
        if v not in cfg.vendors:
            raise SystemExit(f"unknown vendor '{v}'. Known: {sorted(cfg.vendors)}")
    upto = STAGES.index(stage)
    data: dict[str, BrandData] = {}
    for b in brand_ids:
        for vid in (vendors or cfg.brands[b].vendors):
            if vid in cfg.brands[b].vendors:
                stage_normalize(cfg, root, b, vid, as_of)
        if upto >= 1:
            data[b] = stage_validate(cfg, root, b, as_of)
    if upto >= 2:
        from src.report.build import build_reports
        build_reports(cfg, root, data, vendors)
    return data
