"""Plain containers passed between pipeline stages."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any


@dataclass
class VendorStat:
    vendor_id: str
    source_file: str
    n_raw: int
    columns_unmapped: list[str] = field(default_factory=list)


@dataclass
class BrandData:
    brand_id: str
    as_of: date
    candidates: list[dict[str, Any]]          # schema-valid, pre-survivorship (one per vendor/SKU)
    curated: list[dict[str, Any]]             # after survivorship
    rejects: list[dict[str, Any]]
    review: list[dict[str, Any]]
    violations: list[dict[str, Any]]
    conflicts: list[dict[str, Any]]
    survivorship: list[dict[str, Any]]
    vendor_stats: list[VendorStat]
