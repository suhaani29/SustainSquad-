"""HTML + Excel + CSV reports: per brand, per vendor, and a consolidated aggregate-only benchmark.
Per-brand reports are built from that brand's analysis alone, so nothing from another brand can enter."""
from __future__ import annotations

import html
import json
import logging
from pathlib import Path
from typing import Any

import pandas as pd

from src.analysis import analyze_brand, assert_single_brand, vendor_view
from src.config import BrandCfg, Config
from src.models import BrandData
from src.normalize.units import LENGTH_TO_MM, MASS_TO_G

log = logging.getLogger(__name__)
E = html.escape

CSS = """body{font:14px/1.5 system-ui,sans-serif;margin:2rem auto;max-width:1100px;color:#1d2a35;padding:0 1rem}
h1{margin:.2rem 0}h2{margin-top:2rem;border-bottom:2px solid #dde6ee;padding-bottom:.2rem}
table{border-collapse:collapse;width:100%;margin:.6rem 0;font-size:13px}th,td{border:1px solid #dde6ee;padding:4px 8px;text-align:left}
th{background:#eef3f8}.score{font-size:3rem;font-weight:700}.pill{padding:2px 10px;border-radius:99px;background:#e7f3ec}
.muted{color:#6b7c8c}.bar{height:8px;background:#dde6ee;border-radius:4px}.bar i{display:block;height:8px;background:#2f8f6b;border-radius:4px}"""


# ------------------------------------------------------------------ presentation helpers
def label(cfg: Config, brand: BrandCfg, fld: str, value: Any) -> Any:
    """Brand taxonomy label override, else taxonomy label, else the raw code."""
    if value is None:
        return value
    ov = brand.taxonomy_labels.get(fld, {})
    if value in ov:
        return ov[value]
    if fld == "material_type" and value in cfg.taxonomy.materials:
        return cfg.taxonomy.materials[value].label
    return value


def curated_frame(cfg: Config, brand: BrandCfg, rows: list[dict]) -> pd.DataFrame:
    """Curated rows in the brand's report units and labels (brand override of units/labels only)."""
    wu, du = brand.report_units.weight, brand.report_units.dimension
    out = []
    for r in rows:
        x = {k: v for k, v in r.items() if k not in ("extras", "survivorship", "src_unit_cost")}
        if x.get("weight_g") is not None:
            x[f"weight_{wu}"] = round(x.pop("weight_g") / MASS_TO_G[wu], 4)
        for d in ("length", "width", "height"):
            if x.get(f"{d}_mm") is not None:
                x[f"{d}_{du}"] = round(x.pop(f"{d}_mm") / LENGTH_TO_MM[du], 3)
            else:
                x.pop(f"{d}_mm", None)
        x["material_label"] = label(cfg, brand, "material_type", x.get("material_type"))
        x["lineage"] = f'{r["source_file"]}#{r["source_row"]}'
        out.append(x)
    return pd.DataFrame(out)


def _df(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame([{k: (json.dumps(v, default=str) if isinstance(v, (dict, list)) else v)
                          for k, v in r.items()} for r in rows])


def _table(df: pd.DataFrame, limit: int = 60) -> str:
    if df.empty:
        return '<p class="muted">None.</p>'
    more = f'<p class="muted">Showing {limit} of {len(df)}; full list in the Excel file.</p>' if len(df) > limit else ""
    return df.head(limit).to_html(index=False, escape=True, border=0, na_rep="") + more


def _pct(x: float | None) -> str:
    return "n/a" if x is None else f"{x * 100:.1f}%"


# ------------------------------------------------------------------ sections
def sections(cfg: Config, brand: BrandCfg, a: dict[str, Any]) -> dict[str, tuple[str, str]]:
    rd, q, cs = a["readiness"], a["quality"], a["cost"]
    dims = pd.DataFrame([{"dimension": k, "score": v["score"], "weight": v["weight"], "contribution": v["contribution"],
                          "what it measures": v["description"]} for k, v in rd["dimensions"].items()])
    byv = pd.DataFrame([{"vendor": v, **{k: _pct(x) for k, x in m.items() if k != "by_field" and k != "rows"}, "rows": m["rows"]}
                        for v, m in q["by_vendor"].items()])
    miss = pd.DataFrame(a["gaps"]["missing_fields"])
    if not miss.empty:
        miss["vendors_missing"] = miss["vendors_missing"].map(", ".join)
    recs = pd.DataFrame([{"priority": r["priority"], "recommendation": r["title"], "impact": r["impact"], "effort": r["effort"],
                          "affected records": r["evidence"].get("affected_records", ""),
                          "metric (now → target)": (f'{r["evidence"]["metric"]["current"]} → {r["evidence"]["metric"]["target"]}'
                                                    if "metric" in r["evidence"] else ""),
                          "action": r["action"]} for r in a["recommendations"]])
    sus = cs["sustainability"]
    vio = _df(a["tables"]["violations"])
    if not vio.empty:
        vio = vio[["rule_id", "rule_version", "severity", "vendor_id", "sku", "source_file", "source_row", "message", "fix_hint"]]
    return {
        "summary": ("Summary", f'<div class="score">{rd["score"]}</div> <span class="pill">{E(rd["band"])}</span>'
                    f'<p>{q["counts"]["raw_rows"]} source rows · {q["counts"]["curated_skus"]} curated SKUs · '
                    f'{q["counts"]["rejects"]} rejects · {q["counts"]["violations"]} rule violations · '
                    f'{q["counts"]["review_queue"]} code-review items. As of {a["as_of"]}.</p>'),
        "readiness": ("Digital readiness (0-100)", _table(dims) + '<p class="muted">Score = Σ weight × dimension score ÷ Σ weight, '
                      'using config weights plus this brand\'s overrides.</p>'),
        "quality": ("Data quality", f'<p>Completeness {_pct(q["completeness"]["overall"])} · validity {_pct(q["validity"])} · '
                    f'uniqueness {_pct(q["uniqueness"])} · consistency {_pct(q["consistency"])} · timeliness {_pct(q["timeliness"])}</p>' + _table(byv)),
        "gaps": ("Gap analysis", "<h3>Missing fields</h3>" + _table(miss) + "<h3>Manual-process indicators</h3>" +
                 _table(pd.DataFrame(a["gaps"]["manual_indicators"])) + "<h3>Reject reasons</h3>" +
                 _table(pd.DataFrame([{"reason_code": k, "rows": v} for k, v in a["gaps"]["reject_reasons"].items()])) +
                 "<h3>Rule violations</h3>" + _table(vio) + "<h3>Conflicting values</h3>" + _table(_df(a["tables"]["conflicts"]))),
        "sustainability": ("Sustainability", f'<p>Average recycled content {sus["recycled_content_avg"]}% · recyclable '
                           f'{_pct(sus["recyclable_share"])} · conditional {_pct(sus["conditional_share"])} · not recyclable '
                           f'{_pct(sus["not_recyclable_share"])}</p>' + _table(pd.DataFrame(
                               [{"material": label(cfg, brand, "material_type", m), **v} for m, v in sus["by_material"].items()]))),
        "recommendations": ("Recommendations (by impact ÷ effort)", _table(recs)),
        "inventory": ("Data inventory", _table(pd.DataFrame(a["inventory"]))),
        "cost": ("Cost and consolidation", f'<p>Currency: {brand.reporting_currency}</p><h3>Average unit cost by material and vendor</h3>' +
                 _table(_df(cs["cost_by_material_vendor"])) + "<h3>Consolidation opportunities</h3>" + _table(_df(cs["consolidation"])) +
                 "<h3>Material-reduction candidates</h3>" + _table(_df(cs["reduction"]))),
    }


def render_html(cfg: Config, brand: BrandCfg, a: dict[str, Any], title: str | None = None, order: list[str] | None = None) -> str:
    secs = sections(cfg, brand, a)
    body = "".join(f"<h2>{E(secs[k][0])}</h2>{secs[k][1]}" for k in (order or brand.report_template.sections) if k in secs)
    t = title or brand.report_template.title
    return f"<!doctype html><meta charset=utf-8><title>{E(t)}</title><style>{CSS}</style><h1>{E(t)}</h1>{body}"


def write_excel(cfg: Config, brand: BrandCfg, a: dict[str, Any], path: Path) -> None:
    rd, q, cs = a["readiness"], a["quality"], a["cost"]
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        pd.DataFrame([{"brand": brand.display_name, "as_of": a["as_of"], "readiness_score": rd["score"], "band": rd["band"],
                       **{f"count_{k}": v for k, v in q["counts"].items()}}]).to_excel(xw, "Summary", index=False)
        pd.DataFrame([{"dimension": k, **{x: y for x, y in v.items()}} for k, v in rd["dimensions"].items()]).to_excel(xw, "Readiness", index=False)
        pd.DataFrame([{"vendor": v, **{k: x for k, x in m.items() if k != "by_field"}} for v, m in q["by_vendor"].items()]).to_excel(xw, "Quality by vendor", index=False)
        pd.DataFrame(a["gaps"]["missing_fields"]).assign().to_excel(xw, "Missing fields", index=False) if a["gaps"]["missing_fields"] else None
        for name, key in (("Violations", "violations"), ("Rejects", "rejects"), ("Conflicts", "conflicts"),
                          ("Review queue", "review"), ("Consolidation", "consolidation"), ("Reduction", "reduction")):
            _df(a["tables"][key]).to_excel(xw, name, index=False) if a["tables"][key] else None
        pd.DataFrame([{k: v for k, v in r.items() if k != "evidence"} | {"affected": r["evidence"].get("affected_records")}
                      for r in a["recommendations"]]).to_excel(xw, "Recommendations", index=False)
        pd.DataFrame(a["inventory"]).to_excel(xw, "Inventory", index=False)
        _df(cs["cost_by_material_vendor"]).to_excel(xw, "Cost", index=False)
        curated_frame(cfg, brand, a["tables"]["curated"]).to_excel(xw, "Curated", index=False)


# ------------------------------------------------------------------ consolidated (aggregate only)
def benchmark(cfg: Config, analyses: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    """One row per brand, aggregate numbers only: no SKU, vendor-row or source-file detail crosses brands."""
    rows = []
    for b, a in analyses.items():
        rows.append({"brand": cfg.brands[b].display_name, "readiness_score": a["readiness"]["score"], "band": a["readiness"]["band"],
                     "completeness": a["quality"]["completeness"]["overall"], "validity": a["quality"]["validity"],
                     "timeliness": a["quality"]["timeliness"], "recycled_content_avg": a["cost"]["sustainability"]["recycled_content_avg"],
                     "not_recyclable_share": a["cost"]["sustainability"]["not_recyclable_share"],
                     "curated_skus": a["quality"]["counts"]["curated_skus"], "rejects": a["quality"]["counts"]["rejects"],
                     "error_violations": sum(1 for v in a["tables"]["violations"] if v["severity"] == "error"),
                     **{f"dim_{k}": v["score"] for k, v in a["readiness"]["dimensions"].items()}})
    return rows


def build_reports(cfg: Config, root: Path, data: dict[str, BrandData], vendors: list[str] | None = None) -> dict[str, dict]:
    analyses: dict[str, dict] = {}
    for b, bd in data.items():
        brand = cfg.brands[b]
        a = analyze_brand(cfg, bd)
        analyses[b] = a
        out = root / "reports" / b
        out.mkdir(parents=True, exist_ok=True)
        (out / "readiness_report.html").write_text(render_html(cfg, brand, a), encoding="utf-8")
        write_excel(cfg, brand, a, out / "readiness_report.xlsx")
        curated_frame(cfg, brand, a["tables"]["curated"]).to_csv(out / "curated.csv", index=False)
        for v in vendors or [s.vendor_id for s in bd.vendor_stats]:
            if not any(s.vendor_id == v for s in bd.vendor_stats):
                continue
            va = analyze_brand(cfg, vendor_view(bd, v))
            assert_single_brand(va)
            vdir = out / "vendors"; vdir.mkdir(exist_ok=True)
            (vdir / f"{v}.html").write_text(render_html(cfg, brand, va, f"{brand.display_name} · {cfg.vendors[v].display_name}",
                                                        ["summary", "readiness", "quality", "gaps", "inventory", "cost"]), encoding="utf-8")
            write_excel(cfg, brand, va, vdir / f"{v}.xlsx")
    if len(analyses) > 0:
        bench = benchmark(cfg, analyses)
        cdir = root / "reports" / "_consolidated"; cdir.mkdir(parents=True, exist_ok=True)
        df = pd.DataFrame(bench)
        df.to_csv(cdir / "benchmark.csv", index=False)
        df.to_excel(cdir / "benchmark.xlsx", index=False)
        (cdir / "benchmark.html").write_text(
            f"<!doctype html><meta charset=utf-8><title>Cross-brand benchmark</title><style>{CSS}</style>"
            f"<h1>Cross-brand benchmark</h1><p class=muted>Aggregate metrics only. SKU-level data stays in each brand's own report.</p>{_table(df)}",
            encoding="utf-8")
    log.info("reports written for %s", sorted(analyses))
    return analyses
