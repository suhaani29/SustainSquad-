"""Brand-agnostic, vendor-agnostic packaging data analytics."""
