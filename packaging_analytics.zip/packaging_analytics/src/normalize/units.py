"""Unit tables and conversion. Adding a unit is a one-line change here."""
from __future__ import annotations

LENGTH_TO_MM = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4, "ft": 304.8}
MASS_TO_G = {"mg": 0.001, "g": 1.0, "kg": 1000.0, "oz": 28.349523125, "lb": 453.59237, "t": 1_000_000.0}


class UnknownUnit(ValueError):
    pass


def to_mm(value: float, unit: str) -> float:
    try:
        return value * LENGTH_TO_MM[unit]
    except KeyError as e:
        raise UnknownUnit(unit) from e


def to_g(value: float, unit: str) -> float:
    try:
        return value * MASS_TO_G[unit]
    except KeyError as e:
        raise UnknownUnit(unit) from e


def from_mm(value: float, unit: str) -> float:
    return value / LENGTH_TO_MM[unit]


def from_g(value: float, unit: str) -> float:
    return value / MASS_TO_G[unit]
