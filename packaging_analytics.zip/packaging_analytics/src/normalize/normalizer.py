"""Vendor row -> canonical record. Everything vendor/brand specific comes from config."""
from __future__ import annotations

import difflib
import logging
import math
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from src.config import BrandCfg, Config, FieldDef, VendorCfg
from src.ingest.base import RawTable
from src.normalize.currency import UnknownCurrency, convert
from src.normalize.units import LENGTH_TO_MM, MASS_TO_G

log = logging.getLogger(__name__)

DIM_FIELDS = ("length_mm", "width_mm", "height_mm")


class RowError(Exception):
    def __init__(self, code: str, field_: str, raw: Any, detail: str = ""):
        self.code, self.field, self.raw, self.detail = code, field_, raw, detail


@dataclass
class NormResult:
    brand_id: str
    vendor_id: str
    source_file: str
    n_raw: int = 0
    records: list[dict[str, Any]] = field(default_factory=list)
    rejects: list[dict[str, Any]] = field(default_factory=list)
    review: list[dict[str, Any]] = field(default_factory=list)
    columns_seen: list[str] = field(default_factory=list)
    columns_mapped: dict[str, str] = field(default_factory=dict)  # canonical -> raw header
    columns_unmapped: list[str] = field(default_factory=list)


# ------------------------------------------------------------------ scalar parsing
def _is_null(v: Any, tokens: set[str]) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    return isinstance(v, str) and v.strip().lower() in tokens


def parse_number(v: Any, v_cfg: VendorCfg, field_: str) -> float:
    if isinstance(v, bool):
        raise RowError("NON_NUMERIC_VALUE", field_, v)
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("%", "").replace(" ", "")
    th, dec = v_cfg.source.thousands, v_cfg.source.decimal
    if th:
        s = s.replace(th, "")
    if dec != ".":
        s = s.replace(dec, ".")
    try:
        return float(s)
    except ValueError:
        raise RowError("NON_NUMERIC_VALUE", field_, v, f"cannot parse '{v}' as number") from None


def parse_bool(v: Any, v_cfg: VendorCfg, field_: str) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in {t.lower() for t in v_cfg.bool_true}:
        return True
    if s in {t.lower() for t in v_cfg.bool_false}:
        return False
    raise RowError("INVALID_BOOLEAN", field_, v)


def parse_date(v: Any, v_cfg: VendorCfg, field_: str) -> date:
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return datetime.strptime(str(v).strip(), v_cfg.source.date_format).date()
    except ValueError:
        raise RowError("INVALID_DATE", field_, v, f"expected {v_cfg.source.date_format}") from None


def parse_list(v: Any, v_cfg: VendorCfg) -> list[str]:
    if isinstance(v, (list, tuple)):
        return [str(x).strip() for x in v if str(x).strip()]
    sep = v_cfg.source.list_separator
    return [p.strip() for p in str(v).split(sep) if p.strip()]


# ------------------------------------------------------------------ code mapping
def _targets(fd: FieldDef, cfg: Config) -> dict[str, str]:
    """lower-cased synonym -> canonical code for enum fields (the code itself and, for taxonomies, its label)."""
    if fd.type == "enum":
        return {x.lower(): x for x in fd.values or []}
    if fd.taxonomy == "materials":
        out = {k.lower(): k for k in cfg.taxonomy.materials}
        out.update({m.label.lower(): k for k, m in cfg.taxonomy.materials.items()})
        return out
    return {x.lower(): x for x in getattr(cfg.taxonomy, fd.taxonomy or "")}


def map_code(raw: Any, field_: str, fd: FieldDef, vendor: VendorCfg, brand: BrandCfg, cfg: Config
             ) -> tuple[str, dict[str, Any] | None]:
    """Returns (canonical, review_entry|None). Raises RowError(UNMAPPED_*) when not resolvable.
    Exact crosswalk/canonical hits are applied; fuzzy hits are applied only at or above the brand
    threshold (and logged); anything lower goes to the review queue and the row is rejected."""
    key = str(raw).strip().lower()
    xwalk = vendor.code_maps.get(field_, {})
    if key in xwalk:
        return xwalk[key], None
    canon = _targets(fd, cfg)
    if key in canon:
        return canon[key], None
    pool: dict[str, str] = {**canon, **xwalk}
    best, score = None, 0.0
    for cand, tgt in pool.items():
        s = difflib.SequenceMatcher(None, key, cand).ratio()
        if s > score:
            best, score = tgt, s
    entry = {"field": field_, "raw_value": str(raw), "suggestion": best if score >= 0.5 else None,
             "confidence": round(score, 3), "threshold": brand.thresholds.fuzzy_auto_apply}
    if best is not None and score >= brand.thresholds.fuzzy_auto_apply:
        entry["status"] = "auto_applied"
        return best, entry
    entry["status"] = "pending_review"
    raise RowError(f"UNMAPPED_{field_.upper()}", field_, raw, f"no mapping; best guess {entry['suggestion']} ({score:.2f})") \
        from _Review(entry)


class _Review(Exception):
    def __init__(self, entry: dict[str, Any]):
        self.entry = entry


# ------------------------------------------------------------------ table
def _build_column_index(vendor: VendorCfg, columns: list[str]) -> dict[str, str]:
    lowered = {c.strip().lower(): c for c in columns}
    idx: dict[str, str] = {}
    for canon, aliases in vendor.columns.items():
        for a in aliases:
            if a.strip().lower() in lowered:
                idx[canon] = lowered[a.strip().lower()]
                break
    return idx


def normalize_table(cfg: Config, brand_id: str, vendor_id: str, table: RawTable, as_of: date) -> NormResult:
    brand, vendor, sch = cfg.brands[brand_id], cfg.vendors[vendor_id], cfg.schema_
    res = NormResult(brand_id, vendor_id, table.source_file, n_raw=len(table.rows), columns_seen=list(table.columns))
    col_idx = _build_column_index(vendor, table.columns)
    res.columns_mapped = dict(col_idx)
    combined_col = None
    if vendor.dimensions_combined:
        lowered = {c.strip().lower(): c for c in table.columns}
        combined_col = next((lowered[a.strip().lower()] for a in vendor.dimensions_combined.aliases
                             if a.strip().lower() in lowered), None)
    used = set(col_idx.values()) | ({combined_col} if combined_col else set())
    res.columns_unmapped = [c for c in table.columns if c not in used]
    nulls = {t.lower() for t in vendor.null_tokens} | {""}
    ingested_at = datetime.combine(as_of, datetime.min.time()).isoformat()

    def reject(row: dict, err: RowError) -> None:
        res.rejects.append({"brand_id": brand_id, "vendor_id": vendor_id, "source_file": table.source_file,
                            "source_row": row["_source_row"], "stage": "normalize", "reason_code": err.code,
                            "field": err.field, "raw_value": None if err.raw is None else str(err.raw),
                            "detail": err.detail})

    for row in table.rows:
        rec: dict[str, Any] = {"brand_id": brand_id, "vendor_id": vendor_id}
        errors: list[RowError] = []
        reviews: list[dict[str, Any]] = []
        raw_currency = None
        for canon, header in col_idx.items():
            fd = sch.fields[canon]
            raw = row.get(header)
            if _is_null(raw, nulls):
                rec[canon] = None
                continue
            try:
                if fd.type in ("enum", "enum_taxonomy"):
                    rec[canon], rev = map_code(raw, canon, fd, vendor, brand, cfg)
                    if rev:
                        reviews.append(rev)
                elif fd.type == "float":
                    rec[canon] = parse_number(raw, vendor, canon)
                elif fd.type == "int":
                    n = parse_number(raw, vendor, canon)
                    rec[canon] = int(round(n))
                elif fd.type == "bool":
                    rec[canon] = parse_bool(raw, vendor, canon)
                elif fd.type == "date":
                    rec[canon] = parse_date(raw, vendor, canon)
                elif fd.type == "list":
                    rec[canon] = parse_list(raw, vendor)
                else:
                    rec[canon] = str(raw).strip()
            except RowError as e:
                if isinstance(e.__cause__, _Review):
                    rev = e.__cause__.entry
                    reviews.append(rev)
                errors.append(e)
        # combined dimensions column, e.g. "L x W x H"
        if combined_col and not _is_null(row.get(combined_col), nulls):
            parts = [p.strip() for p in str(row[combined_col]).lower().split(vendor.dimensions_combined.separator.lower())]
            try:
                if len(parts) != 3:
                    raise RowError("NON_NUMERIC_VALUE", "dimensions", row[combined_col], "expected 3 parts")
                for name, p in zip(DIM_FIELDS, parts):
                    rec[name] = parse_number(p, vendor, name)
            except RowError as e:
                errors.append(e)
        # unit normalization to canonical mm / g
        for name in DIM_FIELDS:
            if rec.get(name) is not None:
                rec[name] = round(rec[name] * LENGTH_TO_MM[vendor.units.dimension], 4)
        if rec.get("weight_g") is not None:
            rec["weight_g"] = round(rec["weight_g"] * MASS_TO_G[vendor.units.weight], 5)
        # currency normalization to the brand's reporting currency
        src_cur = (rec.get("currency") or vendor.currency).upper()
        rec["src_unit_cost"], rec["src_currency"] = rec.get("unit_cost"), src_cur
        if rec.get("unit_cost") is not None:
            try:
                rec["unit_cost"] = round(convert(rec["unit_cost"], src_cur, brand.reporting_currency, cfg.rates.to_usd), 6)
            except UnknownCurrency:
                errors.append(RowError("UNKNOWN_CURRENCY", "currency", src_cur, f"no rate for {src_cur}"))
        rec["currency"] = brand.reporting_currency
        rec["fx_as_of"] = cfg.rates.as_of.isoformat()
        rec.setdefault("region", None)
        if rec.get("region") is None:
            rec["region"] = brand.default_region
        # lineage + extras
        rec["source_system"] = vendor_id
        rec["source_file"] = table.source_file
        rec["source_row"] = row["_source_row"]
        rec["ingested_at"] = ingested_at
        rec[sch.extras_field] = {c: row[c] for c in res.columns_unmapped
                                 if not _is_null(row.get(c), nulls)}
        for rv in reviews:
            res.review.append({"brand_id": brand_id, "vendor_id": vendor_id, "source_file": table.source_file,
                               "source_row": row["_source_row"], **rv})
        if not rec.get("sku"):
            errors.append(RowError("MISSING_SKU", "sku", None, "blank SKU"))
        if errors:
            for e in errors:
                reject(row, e)
            continue
        res.records.append(rec)

    _dedupe(res)
    log.info("normalize %s/%s: %d raw -> %d records, %d rejects, %d review", brand_id, vendor_id,
             res.n_raw, len(res.records), len(res.rejects), len(res.review))
    return res


def _dedupe(res: NormResult) -> None:
    """Same SKU twice in one source: keep the most recent effective_from (ties: first row)."""
    seen: dict[str, dict[str, Any]] = {}
    keep: list[dict[str, Any]] = []
    for r in res.records:
        prev = seen.get(r["sku"])
        if prev is None:
            seen[r["sku"]] = r
            keep.append(r)
            continue
        newer = (r.get("effective_from") or date.min) > (prev.get("effective_from") or date.min)
        loser = prev if newer else r
        if newer:
            keep[keep.index(prev)] = r
            seen[r["sku"]] = r
        res.rejects.append({"brand_id": res.brand_id, "vendor_id": res.vendor_id, "source_file": res.source_file,
                            "source_row": loser["source_row"], "stage": "normalize",
                            "reason_code": "DUPLICATE_IN_SOURCE", "field": "sku", "raw_value": loser["sku"],
                            "detail": f"duplicate of source row {seen[r['sku']]['source_row']}"})
    res.records = keep
