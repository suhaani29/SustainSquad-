"""Currency conversion through a USD pivot using the dated rate table in config."""
from __future__ import annotations

from datetime import date


class UnknownCurrency(ValueError):
    pass


def rate(src: str, dst: str, to_usd: dict[str, float]) -> float:
    """Multiplier that converts one unit of `src` into `dst`."""
    try:
        return to_usd[src] / to_usd[dst]
    except KeyError as e:
        raise UnknownCurrency(str(e.args[0])) from e


def convert(amount: float, src: str, dst: str, to_usd: dict[str, float]) -> float:
    return amount * rate(src, dst, to_usd)


def as_of_label(d: date) -> str:
    return d.isoformat()
