"""pipeline run --brand X --vendor Y --stage normalize|validate|report"""
from __future__ import annotations

import argparse
import logging
from datetime import date

from src.pipeline import STAGES, run


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="pipeline")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="run the pipeline up to a stage")
    r.add_argument("--brand", action="append", help="brand_id (repeatable); default all")
    r.add_argument("--vendor", action="append", help="vendor_id (repeatable); default all of the brand's vendors")
    r.add_argument("--stage", choices=STAGES, default="report")
    r.add_argument("--config", default="config")
    r.add_argument("--root", default=".")
    r.add_argument("--as-of", type=date.fromisoformat, help="YYYY-MM-DD; default env PIPELINE_AS_OF or the rate table date")
    r.add_argument("-v", "--verbose", action="store_true")
    a = p.parse_args(argv)
    logging.basicConfig(level=logging.INFO if a.verbose else logging.WARNING, format="%(levelname)s %(message)s")
    data = run(a.config, a.root, a.brand, a.vendor, a.stage, a.as_of)
    for b, bd in data.items():
        print(f"{b}: {len(bd.curated)} curated SKUs, {len(bd.rejects)} rejects, {len(bd.violations)} violations")


if __name__ == "__main__":
    main()
