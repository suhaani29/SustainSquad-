"""Rule-driven recommendations from config. Each fires on a metric or a table count and carries evidence."""
from __future__ import annotations

from typing import Any

from src.config import Config, Recommendation
from src.validate.rules import apply_op

MAX_EVIDENCE = 200


def _get(path: str, tree: dict[str, Any]) -> Any:
    cur: Any = tree
    for p in path.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return None
        cur = cur[p]
    return cur


def _match(row: dict[str, Any], where: dict[str, Any]) -> bool:
    for k, want in where.items():
        have = row.get(k)
        if want is None:
            if have not in (None, "", []):
                return False
        elif k == "reason_code":
            if not str(have).startswith(str(want)):
                return False
        elif have != want:
            return False
    return True


def _rows(tables: dict[str, list[dict]], spec: dict[str, Any]) -> list[dict]:
    return [r for r in tables.get(spec["table"], []) if _match(r, spec.get("where", {}))]


def _ref(r: dict[str, Any]) -> dict[str, Any]:
    return {k: r.get(k) for k in ("brand_id", "vendor_id", "sku", "source_file", "source_row", "reason_code",
                                  "rule_id", "field", "material_type") if r.get(k) is not None}


def recommend(cfg: Config, metrics: dict[str, Any], tables: dict[str, list[dict]]) -> list[dict[str, Any]]:
    out = []
    for rec in cfg.recommendations:
        t = rec.trigger
        if t.count is not None:
            value: Any = len(_rows(tables, t.count))
        else:
            value = _get(t.metric or "", metrics)
        if value is None or not apply_op(t.op, value, t.value):
            continue
        ev: dict[str, Any] = {}
        spec = rec.evidence
        if "records" in spec:
            rows = _rows(tables, spec["records"])
            ev["affected_records"] = len(rows)
            ev["sample"] = [_ref(r) for r in rows[:MAX_EVIDENCE]]
        if "metric" in spec:
            cur = _get(spec["metric"], metrics)
            ev["metric"] = {"path": spec["metric"], "current": cur, "target": spec.get("target"),
                            "delta": None if cur is None or spec.get("target") is None else round(spec["target"] - cur, 4)}
        out.append({"rec_id": rec.rec_id, "title": rec.title, "action": rec.action, "area": rec.area,
                    "impact": rec.impact, "effort": rec.effort, "priority": round(rec.impact / rec.effort, 2),
                    "trigger_value": value, "evidence": ev})
    out.sort(key=lambda r: (-r["priority"], -r["impact"], r["rec_id"]))
    return out
