"""Typed, validated configuration. Every brand, vendor, rule and weight lives in YAML;
this module loads it, validates it with pydantic and cross-checks references so a
mistake fails at load time rather than halfway through a run."""
from __future__ import annotations

import logging
from datetime import date
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from src.normalize.units import LENGTH_TO_MM, MASS_TO_G
from src.validate.derived import DERIVED_FIELDS, OPS

log = logging.getLogger(__name__)
SURVIVORSHIP_STRATEGIES = {"preferred_vendor", "most_recent", "highest_completeness"}


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid")


# ---------------------------------------------------------------- schema / taxonomy
class FieldDef(Strict):
    type: Literal["str", "float", "int", "bool", "date", "list", "enum", "enum_taxonomy"]
    required: bool = False
    min: float | None = None
    max: float | None = None
    values: list[str] | None = None
    taxonomy: str | None = None


class CanonicalSchema(Strict):
    version: int
    key: list[str]
    dimension_unit: str
    weight_unit: str
    fields: dict[str, FieldDef]
    system_fields: list[str]
    extras_field: str
    conflict_fields: dict[str, dict[str, float]]

    @model_validator(mode="after")
    def _check(self) -> "CanonicalSchema":
        for k in self.key:
            if k not in self.fields:
                raise ValueError(f"schema key '{k}' is not a field")
        for name, f in self.fields.items():
            if f.type == "enum" and not f.values:
                raise ValueError(f"field {name}: enum needs values")
            if f.type == "enum_taxonomy" and not f.taxonomy:
                raise ValueError(f"field {name}: enum_taxonomy needs taxonomy")
        for name in self.conflict_fields:
            if name not in self.fields:
                raise ValueError(f"conflict_fields: unknown field {name}")
        return self


class Material(Strict):
    family: str
    label: str
    default_recyclability: str


class Taxonomy(Strict):
    categories: list[str]
    regions: list[str]
    materials: dict[str, Material]


class Rates(Strict):
    as_of: date
    to_usd: dict[str, float]


# ---------------------------------------------------------------- vendors
class SourceCfg(Strict):
    format: str
    path_pattern: str
    encoding: str = "utf-8"
    delimiter: str = ","
    decimal: str = "."
    thousands: str | None = None
    date_format: str = "%Y-%m-%d"
    list_separator: str = "|"
    sheet: str | None = None
    header_row: int = 1
    records_path: str | None = None
    url: str | None = None  # api adapter: env var name holding the endpoint, never a secret in YAML


class Capabilities(Strict):
    api: bool = False
    edi: bool = False
    sftp: bool = False
    structured: bool = True
    automated_ingestion: bool = False


class Units(Strict):
    dimension: str
    weight: str

    @field_validator("dimension")
    @classmethod
    def _dim(cls, v: str) -> str:
        if v not in LENGTH_TO_MM:
            raise ValueError(f"unknown length unit {v}")
        return v

    @field_validator("weight")
    @classmethod
    def _wt(cls, v: str) -> str:
        if v not in MASS_TO_G:
            raise ValueError(f"unknown mass unit {v}")
        return v


class DimsCombined(Strict):
    aliases: list[str]
    separator: str = "x"


class VendorCfg(Strict):
    vendor_id: str
    display_name: str
    owner: str
    source: SourceCfg
    units: Units
    currency: str
    null_tokens: list[str] = Field(default_factory=list)
    bool_true: list[str] = Field(default_factory=list)
    bool_false: list[str] = Field(default_factory=list)
    capabilities: Capabilities = Field(default_factory=Capabilities)
    update_cadence_days: int
    manual_indicator_columns: list[str] = Field(default_factory=list)
    columns: dict[str, list[str]]
    dimensions_combined: DimsCombined | None = None
    code_maps: dict[str, dict[str, str]] = Field(default_factory=dict)

    @field_validator("code_maps", mode="before")
    @classmethod
    def _lower_keys(cls, v: Any) -> Any:
        if not isinstance(v, dict):
            return v
        return {f: {str(k).strip().lower(): str(t) for k, t in m.items()} for f, m in v.items()}


# ---------------------------------------------------------------- brands
class Thresholds(Strict):
    fuzzy_auto_apply: float = 0.90
    freshness_days: int = 365
    consolidation_spread_pct: float = 15
    reduction_factor: float = 1.25


class ReportUnits(Strict):
    weight: str = "g"
    dimension: str = "mm"


class ReportTemplate(Strict):
    title: str
    sections: list[str]


class BrandCfg(Strict):
    brand_id: str
    display_name: str
    reporting_currency: str
    default_region: str
    vendors: list[str]
    report_units: ReportUnits = Field(default_factory=ReportUnits)
    taxonomy_labels: dict[str, dict[str, str]] = Field(default_factory=dict)
    thresholds: Thresholds = Field(default_factory=Thresholds)
    required_fields: list[str] = Field(default_factory=list)
    survivorship: list[str]
    preferred_vendors: list[str] = Field(default_factory=list)
    fill_nulls_from_losers: bool = True
    manual_indicator_columns: list[str] = Field(default_factory=list)
    readiness_weights: dict[str, float] = Field(default_factory=dict)
    report_template: ReportTemplate

    @field_validator("survivorship")
    @classmethod
    def _surv(cls, v: list[str]) -> list[str]:
        bad = set(v) - SURVIVORSHIP_STRATEGIES
        if bad:
            raise ValueError(f"unknown survivorship strategies {sorted(bad)}")
        return v


# ---------------------------------------------------------------- rules
class RuleScope(Strict):
    category: list[str] | None = None
    region: list[str] | None = None
    brand: list[str] | None = None
    vendor: list[str] | None = None

    @field_validator("*", mode="before")
    @classmethod
    def _listify(cls, v: Any) -> Any:
        return [v] if isinstance(v, str) else v


class AssertDef(Strict):
    field: str
    op: str
    value: Any = None
    ref: str | None = None  # compare against another field instead of a literal


class RuleDef(Strict):
    rule_id: str
    rule_version: int = 1
    scope: RuleScope = Field(default_factory=RuleScope)
    severity: Literal["error", "warn", "info"]
    when: dict[str, Any] = Field(default_factory=dict)
    assert_: list[AssertDef] = Field(alias="assert")
    message: str
    fix_hint: str = ""
    enabled: bool = True


class RequiredFields(Strict):
    severity: Literal["error", "warn", "info"] = "warn"
    fields: list[str]


class RulesFile(Strict):
    category: str | None = None
    required_fields: RequiredFields | None = None
    rules: list[RuleDef] = Field(default_factory=list)


# ---------------------------------------------------------------- readiness / recommendations
class Dimension(Strict):
    weight: float
    description: str = ""


class CadenceRow(Strict):
    max_days: int | None
    score: float


class Band(Strict):
    min: float
    label: str


class ReadinessCfg(Strict):
    dimensions: dict[str, Dimension]
    cadence_scoring: list[CadenceRow]
    bands: list[Band]


class Trigger(Strict):
    metric: str | None = None
    count: dict[str, Any] | None = None
    op: str
    value: float

    @model_validator(mode="after")
    def _one(self) -> "Trigger":
        if (self.metric is None) == (self.count is None):
            raise ValueError("trigger needs exactly one of metric or count")
        if self.op not in OPS:
            raise ValueError(f"unknown op {self.op}")
        return self


class Recommendation(Strict):
    rec_id: str
    title: str
    action: str
    area: str
    impact: int = Field(ge=1, le=5)
    effort: int = Field(ge=1, le=5)
    trigger: Trigger
    evidence: dict[str, Any] = Field(default_factory=dict)


class RecsFile(Strict):
    recommendations: list[Recommendation]


class Presentation(BaseModel):
    model_config = ConfigDict(extra="allow")
    tower_layers: list[dict[str, Any]] = Field(default_factory=list)
    consumer_guidance: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------- container
class Config(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)
    root: Path
    schema_: CanonicalSchema
    taxonomy: Taxonomy
    rates: Rates
    readiness: ReadinessCfg
    recommendations: list[Recommendation]
    presentation: Presentation
    brands: dict[str, BrandCfg]
    vendors: dict[str, VendorCfg]
    rules: list[RuleDef]
    required_by_category: dict[str, RequiredFields]

    def readiness_weights(self, brand_id: str | None) -> dict[str, float]:
        w = {k: d.weight for k, d in self.readiness.dimensions.items()}
        if brand_id:
            w.update(self.brands[brand_id].readiness_weights)
        return w


def _yaml(path: Path) -> Any:
    with path.open(encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def _validate_refs(cfg: Config) -> None:
    sch, tax = cfg.schema_, cfg.taxonomy
    allowed_fields = set(sch.fields) | set(DERIVED_FIELDS)
    for b in cfg.brands.values():
        for v in b.vendors:
            if v not in cfg.vendors:
                raise ValueError(f"brand {b.brand_id}: unknown vendor {v}")
        for v in b.preferred_vendors:
            if v not in cfg.vendors:
                raise ValueError(f"brand {b.brand_id}: unknown preferred vendor {v}")
        if b.reporting_currency not in cfg.rates.to_usd:
            raise ValueError(f"brand {b.brand_id}: no rate for {b.reporting_currency}")
        if b.default_region not in tax.regions:
            raise ValueError(f"brand {b.brand_id}: unknown region {b.default_region}")
        for f in b.required_fields:
            if f not in sch.fields:
                raise ValueError(f"brand {b.brand_id}: required field {f} not in schema")
        bad = set(b.readiness_weights) - set(cfg.readiness.dimensions)
        if bad:
            raise ValueError(f"brand {b.brand_id}: unknown readiness dimensions {sorted(bad)}")
        if b.report_units.weight not in MASS_TO_G or b.report_units.dimension not in LENGTH_TO_MM:
            raise ValueError(f"brand {b.brand_id}: bad report_units")
    for v in cfg.vendors.values():
        if v.currency not in cfg.rates.to_usd:
            raise ValueError(f"vendor {v.vendor_id}: no rate for {v.currency}")
        for f in v.columns:
            if f not in sch.fields:
                raise ValueError(f"vendor {v.vendor_id}: column map names unknown field {f}")
        for f, m in v.code_maps.items():
            if f not in sch.fields:
                raise ValueError(f"vendor {v.vendor_id}: code_map for unknown field {f}")
            fd = sch.fields[f]
            valid = (set(fd.values or []) if fd.type == "enum"
                     else set(getattr(tax, fd.taxonomy)) if fd.type == "enum_taxonomy" else None)
            if valid is not None:
                bad = {t for t in m.values() if t not in valid}
                if bad:
                    raise ValueError(f"vendor {v.vendor_id}: code_map {f} targets {sorted(bad)} not allowed")
    for r in cfg.rules:
        for cond in r.when:
            if cond not in allowed_fields:
                raise ValueError(f"rule {r.rule_id}: unknown when-field {cond}")
        for a in r.assert_:
            if a.field not in allowed_fields:
                raise ValueError(f"rule {r.rule_id}: unknown field {a.field}")
            if a.op not in OPS:
                raise ValueError(f"rule {r.rule_id}: unknown op {a.op}")
            if a.ref and a.ref not in allowed_fields:
                raise ValueError(f"rule {r.rule_id}: unknown ref field {a.ref}")
        for dim, allowed in (("category", tax.categories), ("region", tax.regions),
                             ("brand", list(cfg.brands)), ("vendor", list(cfg.vendors))):
            for x in getattr(r.scope, dim) or []:
                if x not in allowed:
                    raise ValueError(f"rule {r.rule_id}: scope {dim} '{x}' unknown")
    for cat, rf in cfg.required_by_category.items():
        if cat not in tax.categories:
            raise ValueError(f"required_fields for unknown category {cat}")
        for f in rf.fields:
            if f not in sch.fields:
                raise ValueError(f"required_fields[{cat}]: unknown field {f}")
    wsum = sum(d.weight for d in cfg.readiness.dimensions.values())
    if wsum <= 0:
        raise ValueError("readiness weights must sum to more than zero")


def load_config(config_dir: str | Path) -> Config:
    root = Path(config_dir)
    schema = CanonicalSchema(**_yaml(root / "canonical_schema.yaml"))
    taxonomy = Taxonomy(**_yaml(root / "taxonomy.yaml"))
    rates = Rates(**_yaml(root / "rates.yaml"))
    readiness = ReadinessCfg(**_yaml(root / "readiness.yaml"))
    recs = RecsFile(**_yaml(root / "recommendations.yaml")).recommendations
    pres_path = root / "presentation.yaml"
    presentation = Presentation(**(_yaml(pres_path) or {})) if pres_path.exists() else Presentation()
    brands = {}
    for p in sorted((root / "brands").glob("*.yaml")):
        b = BrandCfg(**_yaml(p))
        if b.brand_id != p.stem:
            raise ValueError(f"{p.name}: brand_id must match file name")
        brands[b.brand_id] = b
    vendors = {}
    for p in sorted((root / "vendors").glob("*.yaml")):
        v = VendorCfg(**_yaml(p))
        if v.vendor_id != p.stem:
            raise ValueError(f"{p.name}: vendor_id must match file name")
        vendors[v.vendor_id] = v
    rules: list[RuleDef] = []
    required: dict[str, RequiredFields] = {}
    for p in sorted((root / "rules").glob("*.yaml")):
        rf = RulesFile(**_yaml(p))
        for r in rf.rules:
            if rf.category and r.scope.category is None:
                r.scope.category = [rf.category]
            rules.append(r)
        if rf.required_fields:
            if not rf.category:
                raise ValueError(f"{p.name}: required_fields needs a category")
            required[rf.category] = rf.required_fields
    cfg = Config(root=root, schema_=schema, taxonomy=taxonomy, rates=rates, readiness=readiness,
                 recommendations=recs, presentation=presentation, brands=brands, vendors=vendors,
                 rules=rules, required_by_category=required)
    _validate_refs(cfg)
    log.info("config loaded: %d brands, %d vendors, %d rules", len(brands), len(vendors), len(rules))
    return cfg
