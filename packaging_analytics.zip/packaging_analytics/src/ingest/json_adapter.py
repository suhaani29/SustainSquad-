from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from src.config import VendorCfg
from src.ingest.base import Adapter, RawTable, register


def flatten(obj: Any, prefix: str = "") -> dict[str, Any]:
    """Nested dicts become dotted headers ('spec.dims.l'); lists stay as values."""
    out: dict[str, Any] = {}
    for k, v in obj.items():
        key = f"{prefix}.{k}" if prefix else k
        if isinstance(v, dict):
            out.update(flatten(v, key))
        else:
            out[key] = v
    return out


@register("json")
class JsonAdapter(Adapter):
    """JSON with a list of records at `records_path`. _source_row is the 1-based index in that list."""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:
        s = vendor.source
        data = json.loads(path.read_text(encoding=s.encoding))
        items = data[s.records_path] if s.records_path else data
        rows, cols = [], []
        for i, item in enumerate(items, start=1):
            d = flatten(item)
            d["_source_row"] = i
            rows.append(d)
            cols += [c for c in d if c not in cols and c != "_source_row"]
        return RawTable(rows=rows, source_file=display_path, columns=cols)
