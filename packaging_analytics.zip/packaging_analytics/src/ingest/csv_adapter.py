from __future__ import annotations

import csv
from pathlib import Path

from src.config import VendorCfg
from src.ingest.base import Adapter, RawTable, register


@register("csv")
class CsvAdapter(Adapter):
    """Delimited text. _source_row is the 1-based line number in the file (header = line 1)."""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:
        s = vendor.source
        with path.open(encoding=s.encoding, newline="") as fh:
            reader = csv.reader(fh, delimiter=s.delimiter)
            header = next(reader)
            rows = []
            for i, rec in enumerate(reader, start=2):
                if not any(c.strip() for c in rec):
                    continue
                d = {h: (rec[j] if j < len(rec) else None) for j, h in enumerate(header)}
                d["_source_row"] = i
                rows.append(d)
        return RawTable(rows=rows, source_file=display_path, columns=header)
