"""Adapter registry. One adapter per source format, picked by the vendor config.
A new format is a new class with @register("name"); a new vendor is only YAML."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from src.config import VendorCfg


@dataclass
class RawTable:
    rows: list[dict[str, Any]]            # raw header -> raw value
    source_file: str
    columns: list[str] = field(default_factory=list)
    source_row_base: int = 1              # documented per adapter; each row also carries _source_row


ADAPTERS: dict[str, type["Adapter"]] = {}


class Adapter:
    format: str = ""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:  # pragma: no cover
        raise NotImplementedError


def register(name: str) -> Callable[[type[Adapter]], type[Adapter]]:
    def deco(cls: type[Adapter]) -> type[Adapter]:
        cls.format = name
        ADAPTERS[name] = cls
        return cls
    return deco


def get_adapter(fmt: str) -> Adapter:
    try:
        return ADAPTERS[fmt]()
    except KeyError:
        raise ValueError(f"no ingest adapter registered for format '{fmt}' (have {sorted(ADAPTERS)})") from None
