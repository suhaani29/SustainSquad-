"""Importing this package registers every adapter."""
from src.ingest import api_adapter, csv_adapter, json_adapter, pdf_table_adapter, xlsx_adapter  # noqa: F401
from src.ingest.base import ADAPTERS, Adapter, RawTable, get_adapter, register  # noqa: F401
