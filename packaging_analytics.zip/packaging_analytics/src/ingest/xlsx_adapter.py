from __future__ import annotations

from pathlib import Path

import openpyxl

from src.config import VendorCfg
from src.ingest.base import Adapter, RawTable, register


@register("xlsx")
class XlsxAdapter(Adapter):
    """Excel sheet with the header on `header_row`. _source_row is the Excel row number."""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:
        s = vendor.source
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb[s.sheet] if s.sheet else wb.active
        rows_iter = ws.iter_rows(values_only=True)
        for _ in range(s.header_row - 1):
            next(rows_iter)
        header = [str(h).strip() if h is not None else f"_col{i}" for i, h in enumerate(next(rows_iter))]
        rows = []
        for i, rec in enumerate(rows_iter, start=s.header_row + 1):
            if rec is None or all(c is None or str(c).strip() == "" for c in rec):
                continue
            d = {h: rec[j] if j < len(rec) else None for j, h in enumerate(header)}
            d["_source_row"] = i
            rows.append(d)
        wb.close()
        return RawTable(rows=rows, source_file=display_path, columns=header)
