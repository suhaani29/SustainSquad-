from __future__ import annotations

import json
import os
from pathlib import Path
from urllib.request import Request, urlopen

from src.config import VendorCfg
from src.ingest.base import Adapter, RawTable, register
from src.ingest.json_adapter import flatten


@register("api")
class ApiAdapter(Adapter):
    """REST pull. The endpoint comes from the environment variable named in source.url and an
    optional bearer token from VENDOR_<ID>_TOKEN; nothing secret lives in config or code.
    A local file path is also accepted so tests and demos run offline."""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:
        s = vendor.source
        endpoint = os.environ.get(s.url or "", "") if s.url else ""
        if endpoint.startswith("http"):
            req = Request(endpoint)
            token = os.environ.get(f"VENDOR_{vendor.vendor_id.upper()}_TOKEN")
            if token:
                req.add_header("Authorization", f"Bearer {token}")
            with urlopen(req, timeout=30) as resp:  # noqa: S310 - endpoint is operator supplied
                data = json.loads(resp.read().decode(s.encoding))
            label = f"api:{vendor.vendor_id}"
        else:
            data = json.loads(path.read_text(encoding=s.encoding))
            label = display_path
        items = data[s.records_path] if s.records_path else data
        rows = []
        for i, item in enumerate(items, start=1):
            d = flatten(item); d["_source_row"] = i; rows.append(d)
        return RawTable(rows=rows, source_file=label, columns=sorted({c for r in rows for c in r if c != "_source_row"}))
