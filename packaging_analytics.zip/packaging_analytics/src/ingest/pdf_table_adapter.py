from __future__ import annotations

from pathlib import Path

from src.config import VendorCfg
from src.ingest.base import Adapter, RawTable, register


@register("pdf_table")
class PdfTableAdapter(Adapter):
    """Tables inside PDFs. Needs the optional `pdfplumber` package; registered so a vendor can
    be configured for it, and fails with a clear message when the dependency is absent.
    _source_row is page*1000 + row index so lineage still points at a page and row."""

    def read(self, vendor: VendorCfg, path: Path, display_path: str) -> RawTable:
        try:
            import pdfplumber  # type: ignore
        except ImportError as e:  # pragma: no cover
            raise RuntimeError("pdf_table adapter needs: pip install pdfplumber") from e
        rows, header = [], None  # pragma: no cover
        with pdfplumber.open(path) as pdf:  # pragma: no cover
            for p, page in enumerate(pdf.pages, start=1):
                for r, tbl_row in enumerate(t for tb in page.extract_tables() for t in tb):
                    if header is None:
                        header = [str(c or "").strip() for c in tbl_row]
                        continue
                    d = dict(zip(header, tbl_row)); d["_source_row"] = p * 1000 + r; rows.append(d)
        return RawTable(rows=rows, source_file=display_path, columns=header or [])  # pragma: no cover
