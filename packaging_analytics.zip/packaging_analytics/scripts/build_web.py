"""Inline web/bundle.json into web/template.html -> web/packaging-data-towers.html (one self-contained page)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MARK = "null/*BUNDLE*/"
tpl = (ROOT / "web/template.html").read_text(encoding="utf-8")
assert tpl.count(MARK) == 1, "template must contain exactly one bundle marker"
data = (ROOT / "web/bundle.json").read_text(encoding="utf-8").replace("</", "<\\/")
out = ROOT / "web/packaging-data-towers.html"
out.write_text(tpl.replace(MARK, data), encoding="utf-8")
print(f"wrote {out} ({out.stat().st_size // 1024} KB)")
