"""Generate deterministic synthetic raw packaging data.

3 brands x 3 vendors, each vendor in its own format, unit system and currency,
with seeded quality problems (missing values, conflicts, typos, bad rows).
All vendor/brand differences come from the tables below, never from pipeline code.

Usage: python scripts/generate_sample_data.py [--out data/raw] [--seed 7]
"""
from __future__ import annotations

import argparse
import csv
import json
import random
from datetime import date, datetime, timedelta
from pathlib import Path

import openpyxl

TO_USD = {"USD": 1.0, "EUR": 1.08, "INR": 0.0119}
MAT_COST_USD = {"PET": .09, "HDPE": .12, "PP": .08, "PVC": .07, "LDPE": .03, "EPS": .15, "MULTILAYER": .06,
                "GLASS": .35, "ALUMINIUM": .14, "STEEL": .22, "PAPERBOARD": .05, "CORRUGATED": .28,
                "MOLDED_PULP": .12, "BIOPLASTIC": .15}
DEFAULT_RECYCLABILITY = {"PVC": "not_recyclable", "EPS": "not_recyclable", "MULTILAYER": "not_recyclable",
                         "LDPE": "conditionally_recyclable", "BIOPLASTIC": "conditionally_recyclable"}
PLASTICS = {"PET", "HDPE", "PP", "PVC", "LDPE", "EPS", "BIOPLASTIC"}

# (name, level, material, weight_g, (L,W,H mm), recycled_pct, extras)
T = {
    "food_beverage": [
        ("Water bottle 500ml", "primary", "PET", 24, (65, 65, 205), 30, {"fc": True, "shelf": 365, "barrier": "low"}),
        ("Milk jug 1L", "primary", "HDPE", 38, (95, 70, 230), 25, {"fc": True, "shelf": 14, "barrier": "low"}),
        ("Sauce jar 350g", "primary", "GLASS", 210, (75, 75, 110), 40, {"fc": True, "shelf": 540, "barrier": "high", "fragile": True}),
        ("Beverage can 330ml", "primary", "ALUMINIUM", 13, (66, 66, 122), 70, {"fc": True, "shelf": 365, "barrier": "high"}),
        ("Cereal carton", "primary", "PAPERBOARD", 60, (200, 70, 300), 80, {"fc": True, "shelf": 270, "barrier": "low"}),
        ("Snack pouch", "primary", "MULTILAYER", 6, (150, 20, 220), 0, {"fc": True, "shelf": 270, "barrier": "high"}),
        ("Yogurt cup", "primary", "PP", 7, (80, 80, 70), 0, {"fc": True, "shelf": 30, "barrier": "low"}),
        ("Deli tray", "primary", "PVC", 18, (200, 140, 40), 0, {"fc": True, "shelf": 10, "barrier": "none"}),
        ("Shipper case", "secondary", "CORRUGATED", 420, (400, 300, 250), 75, {"fc": False}),
        ("Pallet wrap", "tertiary", "LDPE", 280, (500, 500, 50), 30, {"fc": False}),
        ("Egg tray", "secondary", "MOLDED_PULP", 85, (300, 300, 70), 100, {"fc": False}),
        ("Soup can", "primary", "STEEL", 60, (73, 73, 110), 30, {"fc": True, "shelf": 730, "barrier": "high"}),
    ],
    "personal_care": [
        ("Shampoo bottle 300ml", "primary", "HDPE", 28, (60, 40, 180), 50, {"fc": False}),
        ("Lotion bottle 200ml", "primary", "PET", 22, (50, 35, 170), 30, {"fc": False}),
        ("Perfume bottle 50ml", "primary", "GLASS", 150, (45, 30, 95), 20, {"fc": False, "fragile": True}),
        ("Aerosol can 150ml", "primary", "ALUMINIUM", 45, (45, 45, 160), 40, {"fc": False, "hazmat": "UN1950"}),
        ("Cream jar 50ml", "primary", "PP", 18, (60, 60, 45), 20, {"fc": False}),
        ("Product carton", "primary", "PAPERBOARD", 40, (60, 60, 180), 70, {"fc": False}),
        ("Toothpaste tube", "primary", "MULTILAYER", 10, (35, 20, 160), 0, {"fc": False}),
        ("Compact case", "primary", "BIOPLASTIC", 25, (70, 70, 18), 0, {"fc": False}),
        ("Shipper case", "secondary", "CORRUGATED", 380, (380, 280, 220), 70, {"fc": False}),
        ("Protective insert", "secondary", "EPS", 12, (200, 150, 50), 0, {"fc": False}),
        ("Blister pack", "primary", "PVC", 5, (120, 60, 15), 0, {"fc": False}),
        ("Display tray", "secondary", "MOLDED_PULP", 55, (300, 200, 60), 100, {"fc": False}),
    ],
    "electronics": [
        ("Retail box", "primary", "CORRUGATED", 310, (320, 220, 120), 70, {"fc": False}),
        ("Cushion insert", "primary", "EPS", 38, (300, 200, 60), 0, {"fc": False}),
        ("Pulp tray", "primary", "MOLDED_PULP", 70, (280, 180, 40), 100, {"fc": False}),
        ("Anti-static bag", "primary", "LDPE", 8, (200, 150, 5), 10, {"fc": False}),
        ("Sleeve", "primary", "PAPERBOARD", 45, (330, 230, 20), 75, {"fc": False}),
        ("Clamshell", "primary", "PP", 30, (150, 100, 40), 15, {"fc": False}),
        ("Master carton", "secondary", "CORRUGATED", 1100, (600, 400, 300), 65, {"fc": False}),
        ("Pallet stretch film", "tertiary", "LDPE", 320, (500, 500, 60), 20, {"fc": False}),
        ("Blister", "primary", "PET", 14, (160, 90, 20), 25, {"fc": False}),
        ("Steel strapping", "tertiary", "STEEL", 220, (400, 30, 30), 40, {"fc": False}),
        ("Battery shipper", "secondary", "CORRUGATED", 520, (400, 300, 150), 60, {"fc": False, "hazmat": "UN3481"}),
        ("Foil bag", "primary", "MULTILAYER", 12, (250, 180, 4), 0, {"fc": False}),
    ],
}

BRANDS = {
    "aurora": {"prefix": "AUR", "main": "food_beverage", "others": ["personal_care"], "regions": ["US", "US", "EU"], "default_region": "US"},
    "lumen": {"prefix": "LUM", "main": "personal_care", "others": ["food_beverage"], "regions": ["EU", "EU", "IN"], "default_region": "EU"},
    "voltix": {"prefix": "VOL", "main": "electronics", "others": ["personal_care"], "regions": ["US", "IN", "IN"], "default_region": "IN"},
}

VENDORS = {
    "nordpack": {"price": 1.12, "missing": 0.04, "currency": "EUR", "ext": "csv"},
    "pacificflex": {"price": 1.00, "missing": 0.08, "currency": "USD", "ext": "json"},
    "andes_sourcing": {"price": 0.82, "missing": 0.25, "currency": "INR", "ext": "xlsx"},
}

DE_CAT = {"food_beverage": "Lebensmittel & Getränke", "personal_care": "Körperpflege", "electronics": "Elektronik"}
DE_LEVEL = {"primary": "Primär", "secondary": "Sekundär", "tertiary": "Tertiär"}
DE_MAT = {"PET": "PET", "HDPE": "HDPE", "PP": "PP", "PVC": "PVC", "LDPE": "LDPE", "EPS": "EPS", "BIOPLASTIC": "PLA",
          "MULTILAYER": "VERB", "GLASS": "GLAS", "ALUMINIUM": "ALU", "STEEL": "STAHL", "PAPERBOARD": "KARTON",
          "CORRUGATED": "WELLPAPPE", "MOLDED_PULP": "ZELLSTOFF"}
DE_REC = {"recyclable": "Ja", "conditionally_recyclable": "Bedingt", "not_recyclable": "Nein"}
DE_BAR = {"none": "keine", "low": "niedrig", "high": "hoch"}
PF_CAT = {"food_beverage": "FNB", "personal_care": "PCARE", "electronics": "ELEC"}
PF_LEVEL = {"primary": "unit", "secondary": "case", "tertiary": "pallet"}
PF_MAT = {"PET": "PETE", "HDPE": "HDPE", "PP": "PP", "PVC": "PVC", "LDPE": "LDPE", "EPS": "EPS", "BIOPLASTIC": "PLA",
          "MULTILAYER": "MLP", "GLASS": "GLS", "ALUMINIUM": "AL", "STEEL": "STL", "PAPERBOARD": "PBD",
          "CORRUGATED": "CORR", "MOLDED_PULP": "PULP"}
PF_REC = {"recyclable": "Y", "conditionally_recyclable": "COND", "not_recyclable": "N"}
AN_CAT = {"food_beverage": "Food & Beverage", "personal_care": "Personal Care", "electronics": "Electronics"}
AN_LEVEL = {"primary": "Primary", "secondary": "Secondary", "tertiary": "Tertiary"}
AN_MAT = {"PET": "PET Plastic", "HDPE": "HDPE Plastic", "PP": "PP Plastic", "PVC": "PVC Plastic", "LDPE": "LDPE Film",
          "EPS": "Thermocol", "BIOPLASTIC": "PLA Bioplastic", "MULTILAYER": "Multilayer Laminate", "GLASS": "Glass",
          "ALUMINIUM": "Aluminium", "STEEL": "Steel", "PAPERBOARD": "Paperboard", "CORRUGATED": "Corrugated Box",
          "MOLDED_PULP": "Molded Pulp"}
AN_REC = {"recyclable": "Recyclable", "conditionally_recyclable": "Partially", "not_recyclable": "Non-recyclable"}


def build_catalog(brand: str, cfg: dict, rng: random.Random, n: int = 36) -> list[dict]:
    pool = [(cfg["main"], t) for t in T[cfg["main"]]] * 2
    for c in cfg["others"]:
        pool += [(c, t) for t in T[c]]
    rng.shuffle(pool)
    skus, seen = [], set()
    for cat, (name, level, mat, w, dims, rec, ex) in pool:
        if len(skus) >= n:
            break
        key = (cat, name)
        if key in seen:
            name = f"{name} v2"
        seen.add(key)
        i = len(skus) + 1
        region = rng.choice(cfg["regions"])
        w2 = round(w * rng.uniform(.9, 1.15), 1)
        recp = max(0, min(100, round(rec + rng.choice([0, 0, 0, 5, -5, 10]))))
        flags = []
        if rng.random() < .7:
            if region == "EU" and level == "primary":
                flags.append("PPWR")
            if mat in PLASTICS and region == "US":
                flags.append("EPR")
            if mat in PLASTICS and region == "IN":
                flags.append("EPR_IN")
        certs = []
        if mat in ("CORRUGATED", "PAPERBOARD", "MOLDED_PULP") and rng.random() < .6:
            certs.append("FSC")
        if ex.get("fc") and rng.random() < .8:
            certs.append("FOOD_GRADE")
        if ex.get("hazmat") == "UN3481" and rng.random() < .5:
            certs.append("UN38.3")
        if ex.get("hazmat") == "UN1950" and rng.random() < .6:
            certs.append("UN_SPEC")
        if rng.random() < .3:
            certs.append("ISO14001")
        skus.append({
            "sku": f"{cfg['prefix']}-{i:03d}", "name": name, "category": cat, "level": level, "mat": mat, "w": w2,
            "dims": tuple(round(d * rng.uniform(.95, 1.08), 1) for d in dims), "rec_pct": recp,
            "recyclability": DEFAULT_RECYCLABILITY.get(mat, "recyclable"), "region": region,
            "cost_usd": MAT_COST_USD[mat] * (w2 / max(w, 1)) ** .5 * rng.uniform(.9, 1.15),
            "moq": rng.choice([500, 1000, 2500, 5000]), "lead": rng.choice([14, 21, 28, 35, 45, 60, 75]),
            "certs": certs, "flags": flags, "fc": ex.get("fc"), "shelf": ex.get("shelf"), "barrier": ex.get("barrier"),
            "fragile": ex.get("fragile", False), "hazmat": ex.get("hazmat"),
        })
    return skus


def eff_date(rng: random.Random) -> date:
    if rng.random() < .15:
        return date(2024, rng.randint(1, 12), rng.randint(1, 28))
    return date(2025, 6, 1) + timedelta(days=rng.randint(0, 480))


def vendor_view(sku: dict, vendor: str, rng: random.Random) -> dict:
    """What one vendor knows about a SKU, with that vendor's noise and gaps."""
    v = VENDORS[vendor]
    miss = v["missing"]
    out = dict(sku)
    out["w"] = sku["w"] * (rng.uniform(1.08, 1.18) if rng.random() < .12 else rng.uniform(.99, 1.01))
    out["cost_vendor"] = sku["cost_usd"] * v["price"] * rng.uniform(.95, 1.05) / TO_USD[v["currency"]]
    out["eff"] = eff_date(rng)
    out["eff_to"] = out["eff"] + timedelta(days=rng.choice([365, 730])) if rng.random() < .5 else None
    for f in ("w", "rec_pct", "recyclability", "cost_vendor", "lead", "hazmat_k", "shelf", "barrier", "fc", "fragile"):
        out[f"miss_{f}"] = rng.random() < miss
    out["miss_certs"] = rng.random() < miss * 1.5
    out["miss_flags"] = rng.random() < miss * 1.5
    return out


def fmt_de(x, nd=2):
    return f"{x:,.{nd}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def write_nordpack(rows, path: Path, rng):
    cols = ["Artikelnr", "Bezeichnung", "Kategorie", "Verpackungsebene", "Material", "Länge (mm)", "Breite (mm)",
            "Höhe (mm)", "Gewicht (kg)", "Rezyklatanteil (%)", "Recyclingfähig", "Stückpreis", "Währung", "MOQ",
            "Lieferzeit (Tage)", "Zertifikate", "Regulatorische Hinweise", "Gültig ab", "Gültig bis", "Region",
            "Lebensmittelkontakt", "Haltbarkeit (Tage)", "Barriere", "Zerbrechlich", "Gefahrgut", "Anmerkung", "Lagerort"]
    out = []
    for r in rows:
        d = {c: "" for c in cols}
        L, W, H = r["dims"]
        d.update({"Artikelnr": r["sku"], "Bezeichnung": r["name"], "Kategorie": DE_CAT[r["category"]],
                  "Verpackungsebene": DE_LEVEL[r["level"]], "Material": DE_MAT[r["mat"]],
                  "Länge (mm)": fmt_de(L, 1), "Breite (mm)": fmt_de(W, 1), "Höhe (mm)": fmt_de(H, 1),
                  "Währung": "EUR", "MOQ": r["moq"], "Gültig ab": r["eff"].strftime("%d.%m.%Y"),
                  "Gültig bis": r["eff_to"].strftime("%d.%m.%Y") if r["eff_to"] else "", "Region": r["region"],
                  "Lagerort": f"HH-{rng.randint(1, 40)}"})
        if not r["miss_w"]: d["Gewicht (kg)"] = fmt_de(r["w"] / 1000, 4)
        if not r["miss_rec_pct"]: d["Rezyklatanteil (%)"] = r["rec_pct"]
        if not r["miss_recyclability"]: d["Recyclingfähig"] = DE_REC[r["recyclability"]]
        if not r["miss_cost_vendor"]: d["Stückpreis"] = fmt_de(r["cost_vendor"], 3)
        if not r["miss_lead"]: d["Lieferzeit (Tage)"] = r["lead"]
        if not r["miss_certs"]: d["Zertifikate"] = "|".join(r["certs"])
        if not r["miss_flags"]: d["Regulatorische Hinweise"] = "|".join(r["flags"])
        if r["fc"] is not None and not r["miss_fc"]: d["Lebensmittelkontakt"] = "Ja" if r["fc"] else "Nein"
        if r["shelf"] and not r["miss_shelf"]: d["Haltbarkeit (Tage)"] = r["shelf"]
        if r["barrier"] and not r["miss_barrier"]: d["Barriere"] = DE_BAR[r["barrier"]]
        d["Zerbrechlich"] = "Ja" if r["fragile"] else "Nein"
        if r["hazmat"]: d["Gefahrgut"] = r["hazmat"]
        if rng.random() < .1: d["Anmerkung"] = "Muster angefragt"
        out.append(d)
    # seeded problems
    if len(out) > 8:
        out[2]["Gewicht (kg)"] = "ca. 12"                      # non numeric
        out[4]["Währung"] = "EURO"                              # unknown currency
        out[5]["Material"] = "Wellpape"                         # typo, fuzzy auto
        out[6]["Rezyklatanteil (%)"] = 140                      # out of range
        out[7]["Verpackungsebene"] = "Palette XL"               # unmapped level
        out[3]["Gewicht (kg)"] = fmt_de(-0.012, 3)               # negative
    out.append(dict(out[1]))                                    # duplicate row in source
    out[-1]["Gültig ab"] = (rows[1]["eff"] + timedelta(days=20)).strftime("%d.%m.%Y")
    with path.open("w", encoding="latin-1", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols, delimiter=";")
        w.writeheader(); w.writerows(out)


def write_pacificflex(rows, path: Path, rng):
    items = []
    for r in rows:
        L, W, H = (round(d / 25.4, 2) for d in r["dims"])
        spec = {"material_code": PF_MAT[r["mat"]], "dims": {"l": L, "w": W, "h": H}, "fragile": r["fragile"]}
        if not r["miss_w"]: spec["weight_oz"] = round(r["w"] / 28.3495, 3)
        if not r["miss_rec_pct"]: spec["recycled_pct"] = r["rec_pct"]
        if not r["miss_recyclability"]: spec["recyclable"] = PF_REC[r["recyclability"]]
        if r["shelf"] and not r["miss_shelf"]: spec["shelf_life_days"] = r["shelf"]
        if r["barrier"] and not r["miss_barrier"]: spec["barrier"] = r["barrier"]
        if r["hazmat"]: spec["hazmat"] = r["hazmat"]
        pricing = {"moq": r["moq"]}
        if not r["miss_cost_vendor"]: pricing["unit_usd"] = round(r["cost_vendor"], 4)
        if not r["miss_lead"]: pricing["lead_days"] = r["lead"]
        comp = {}
        if not r["miss_certs"]: comp["certs"] = list(r["certs"])
        if not r["miss_flags"]: comp["flags"] = list(r["flags"])
        it = {"id": r["sku"], "title": r["name"], "cat": PF_CAT[r["category"]], "level": PF_LEVEL[r["level"]],
              "spec": spec, "pricing": pricing, "compliance": comp, "valid_from": r["eff"].isoformat(),
              "valid_to": r["eff_to"].isoformat() if r["eff_to"] else None, "region": r["region"]}
        if r["fc"] is not None and not r["miss_fc"]: it["food_contact"] = bool(r["fc"])
        if rng.random() < .1: it["notes"] = "price under review"
        items.append(it)
    if len(items) > 8:
        items[2]["spec"]["weight_oz"] = -0.4                      # negative
        items[3]["spec"]["material_code"] = "PETE "               # trailing space, still maps
        items[4]["spec"]["material_code"] = "XYZ-9"               # unmapped
        items[5]["spec"]["recycled_pct"] = 120                    # out of range
        items[6]["level"] = "kit"                                 # unmapped level
        items[7]["spec"]["weight_oz"] = 900.0                     # implausible density
    items.append(json.loads(json.dumps(items[1])))               # duplicate
    items[-1]["valid_from"] = (rows[1]["eff"] + timedelta(days=20)).isoformat()
    path.write_text(json.dumps({"generated": "2026-09-30", "items": items}, indent=1), encoding="utf-8")


def write_andes(rows, path: Path, rng):
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Packaging Master"
    ws["A1"] = "Andes Sourcing - packaging master list"; ws["A2"] = "Updated manually each quarter"
    cols = ["Item Code", "Description", "Category", "Pack Level", "Material", "Dimensions (L x W x H cm)", "Net Wt (g)",
            "Recycled %", "Recyclable?", "Rate (INR)", "MOQ", "Lead Time (days)", "Certs", "Updated On", "Food Contact",
            "Fragile", "Hazmat Class", "Remarks", "Godown"]
    for i, c in enumerate(cols, 1):
        ws.cell(row=3, column=i, value=c)
    data = []
    for r in rows:
        L, W, H = (round(d / 10, 1) for d in r["dims"])
        d = {c: None for c in cols}
        d.update({"Item Code": r["sku"], "Description": r["name"], "Category": AN_CAT[r["category"]],
                  "Pack Level": AN_LEVEL[r["level"]], "Material": AN_MAT[r["mat"]],
                  "Dimensions (L x W x H cm)": f"{L} x {W} x {H}", "MOQ": r["moq"],
                  "Updated On": r["eff"].isoformat(), "Fragile": "Yes" if r["fragile"] else "No",
                  "Godown": f"G{rng.randint(1, 9)}"})
        if not r["miss_w"]: d["Net Wt (g)"] = round(r["w"], 1)
        if not r["miss_rec_pct"]: d["Recycled %"] = r["rec_pct"]
        if not r["miss_recyclability"]: d["Recyclable?"] = AN_REC[r["recyclability"]] if rng.random() > .1 else "NA"
        if not r["miss_cost_vendor"]: d["Rate (INR)"] = round(r["cost_vendor"], 2)
        if not r["miss_lead"]: d["Lead Time (days)"] = r["lead"]
        if not r["miss_certs"]: d["Certs"] = ", ".join(r["certs"])
        if r["fc"] is not None and not r["miss_fc"]: d["Food Contact"] = "Yes" if r["fc"] else "No"
        if r["hazmat"]: d["Hazmat Class"] = r["hazmat"]
        if rng.random() < .25: d["Remarks"] = rng.choice(["call vendor", "rate negotiable", "check sample"])
        data.append(d)
    if len(data) > 8:
        data[1]["Material"] = "Aluminum"                         # spelling variant, fuzzy auto
        data[2]["Material"] = "Kraft Laminate XJ"                # unmapped, review queue
        data[3]["Item Code"] = None                              # blank sku
        data[4]["Net Wt (g)"] = "approx 40"                      # non numeric
        data[5]["Material"] = "Corrug. Box"                      # low confidence fuzzy -> review
        data[6]["Recycled %"] = -5                               # out of range
        data[7]["Pack Level"] = "Sample"                         # unmapped
    data.append(dict(data[1]))                                   # duplicate
    data[-1]["Updated On"] = (rows[1]["eff"] + timedelta(days=20)).isoformat()
    for ridx, d in enumerate(data, start=4):
        for cidx, c in enumerate(cols, 1):
            ws.cell(row=ridx, column=cidx, value=d[c])
    wb.save(path)


WRITERS = {"nordpack": write_nordpack, "pacificflex": write_pacificflex, "andes_sourcing": write_andes}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/raw")
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    out = Path(a.out)
    for brand, cfg in BRANDS.items():
        rng = random.Random(f"{a.seed}-{brand}")
        catalog = build_catalog(brand, cfg, rng)
        per_vendor: dict[str, list] = {v: [] for v in VENDORS}
        for s in catalog:
            k = rng.choices([1, 2, 3], weights=[.5, .35, .15])[0]
            for v in rng.sample(list(VENDORS), k):
                per_vendor[v].append(vendor_view(s, v, rng))
        (out / brand).mkdir(parents=True, exist_ok=True)
        for v, rows in per_vendor.items():
            path = out / brand / f"{v}.{VENDORS[v]['ext']}"
            WRITERS[v](rows, path, rng)
            print(f"{path}  {len(rows)} rows")


if __name__ == "__main__":
    main()
