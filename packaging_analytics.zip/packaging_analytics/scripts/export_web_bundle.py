"""Pipeline output -> web/bundle.json for the 3D page. Reads the same analysis the reports use,
so the page can never show a number the Python side does not produce."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.analysis import analyze_brand  # noqa: E402
from src.config import load_config  # noqa: E402
from src.pipeline import resolve_as_of, run  # noqa: E402
from src.report.build import benchmark, label  # noqa: E402

CURATED = ["sku", "product_name", "vendor_id", "product_category", "packaging_level", "material_type", "region",
           "weight_g", "length_mm", "width_mm", "height_mm", "unit_cost", "currency", "lead_time_days",
           "recycled_content_pct", "recyclability", "regulatory_flags", "certifications", "food_contact",
           "effective_from", "source_file", "source_row"]
VIOL = ["rule_id", "rule_version", "severity", "sku", "vendor_id", "message", "fix_hint", "fields", "source_file", "source_row"]
REJ = ["vendor_id", "source_file", "source_row", "reason_code", "field", "raw_value", "detail", "stage"]
REV = ["vendor_id", "source_file", "source_row", "field", "raw_value", "suggestion", "confidence", "threshold", "status"]


def pick(rows, keys):
    return [{k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in ((k, r.get(k)) for k in keys)} for r in rows]


def build(root: Path = ROOT) -> dict:
    cfg = load_config(root / "config")
    data = run("config", root, stage="validate")
    brands, analyses = [], {}
    for b, bd in data.items():
        a = analyze_brand(cfg, bd)
        analyses[b] = a
        bc = cfg.brands[b]
        surv = {s["sku"]: s for s in bd.survivorship}
        cur = pick(a["tables"]["curated"], CURATED)
        for c, src in zip(cur, a["tables"]["curated"]):
            c["material_label"] = label(cfg, bc, "material_type", c["material_type"])
            c["surv"] = {k: surv[c["sku"]][k] for k in ("winner_vendor", "candidates", "decided_by", "filled_from", "lineage")}
        brands.append({
            "id": b, "name": bc.display_name, "currency": bc.reporting_currency, "region": bc.default_region,
            "report_units": bc.report_units.model_dump(), "thresholds": bc.thresholds.model_dump(),
            "survivorship": bc.survivorship, "preferred_vendors": bc.preferred_vendors,
            "required_fields": bc.required_fields, "weights": a["weights"], "readiness": a["readiness"],
            "quality": a["quality"], "gaps": a["gaps"], "inventory": a["inventory"], "cost": a["cost"],
            "recommendations": [{**r, "evidence": {**r["evidence"], "sample": r["evidence"].get("sample", [])[:25]}}
                                for r in a["recommendations"]],
            "curated": cur, "violations": pick(a["tables"]["violations"], VIOL), "rejects": pick(a["tables"]["rejects"], REJ),
            "review": pick(a["tables"]["review"], REV), "conflicts": [{k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in c.items()} for c in a["tables"]["conflicts"]],
        })
    return {
        "as_of": resolve_as_of(cfg).isoformat(), "fx_as_of": cfg.rates.as_of.isoformat(),
        "layers": cfg.presentation.tower_layers, "guidance": cfg.presentation.consumer_guidance,
        "base_weights": {k: d.weight for k, d in cfg.readiness.dimensions.items()},
        "dimension_info": {k: d.description for k, d in cfg.readiness.dimensions.items()},
        "bands": [b.model_dump() for b in cfg.readiness.bands],
        "rules": [{"rule_id": r.rule_id, "version": r.rule_version, "severity": r.severity, "message": r.message,
                   "scope": {k: v for k, v in r.scope.model_dump().items() if v}} for r in cfg.rules],
        "brands": brands, "benchmark": benchmark(cfg, analyses),
    }


if __name__ == "__main__":
    out = ROOT / "web" / "bundle.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(build(), default=str, separators=(",", ":")), encoding="utf-8")
    print(f"wrote {out} ({out.stat().st_size // 1024} KB)")
