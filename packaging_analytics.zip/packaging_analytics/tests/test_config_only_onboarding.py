"""Acceptance: a 4th vendor and a 4th brand need only YAML (plus the vendor's own data file)."""
import csv
import shutil
from pathlib import Path

from src.config import load_config
from src.pipeline import run

VENDOR = """vendor_id: zenpack
display_name: ZenPack KK
owner: Procurement JP
source: {format: csv, path_pattern: "data/raw/{brand}/zenpack.csv", encoding: utf-8, delimiter: ",", decimal: ".", date_format: "%Y/%m/%d"}
units: {dimension: cm, weight: lb}
currency: GBP
null_tokens: ["", "-"]
bool_true: ["y"]
bool_false: ["n"]
capabilities: {api: true, edi: false, sftp: false, structured: true, automated_ingestion: true}
update_cadence_days: 14
columns:
  sku: ["Code"]
  product_category: ["Type"]
  packaging_level: ["Level"]
  material_type: ["Mat"]
  length_mm: ["L"]
  width_mm: ["W"]
  height_mm: ["H"]
  weight_g: ["Wt lb"]
  unit_cost: ["Price"]
  recycled_content_pct: ["Recycled"]
  recyclability: ["Recyc"]
  effective_from: ["Date"]
code_maps:
  product_category: {food: food_beverage, care: personal_care}
  packaging_level: {pri: primary, sec: secondary}
  material_type: {plastic1: PET, board: PAPERBOARD}
  recyclability: {y: recyclable, n: not_recyclable}
"""
BRAND = """brand_id: nova
display_name: Nova Home
reporting_currency: GBP
default_region: EU
vendors: [zenpack]
thresholds: {fuzzy_auto_apply: 0.9, freshness_days: 365, consolidation_spread_pct: 15, reduction_factor: 1.25}
required_fields: [weight_g]
survivorship: [highest_completeness]
report_template: {title: "Nova readiness", sections: [summary, readiness, quality]}
"""


def test_new_vendor_and_brand_are_yaml_only(ws):
    (ws / "config/vendors/zenpack.yaml").write_text(VENDOR)
    (ws / "config/brands/nova.yaml").write_text(BRAND)
    (ws / "data/raw/nova").mkdir()
    with (ws / "data/raw/nova/zenpack.csv").open("w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Code", "Type", "Level", "Mat", "L", "W", "H", "Wt lb", "Price", "Recycled", "Recyc", "Date", "Extra"])
        w.writerow(["N-1", "food", "pri", "plastic1", 10, 5, 4, 0.5, 0.2, 30, "y", "2026/09/01", "keep me"])
        w.writerow(["N-2", "care", "sec", "board", 20, 10, 8, 1.0, 0.5, 80, "y", "2026/08/01", ""])
    cfg = load_config(ws / "config")
    assert "nova" in cfg.brands and "zenpack" in cfg.vendors
    data = run("config", ws, stage="report")
    nova = data["nova"]
    assert {r["sku"] for r in nova.curated} == {"N-1", "N-2"}
    n1 = next(r for r in nova.curated if r["sku"] == "N-1")
    assert abs(n1["weight_g"] - 226.796) < 0.01 and n1["length_mm"] == 100 and n1["currency"] == "GBP"
    assert n1["extras"] == {"Extra": "keep me"}
    assert (ws / "reports/nova/readiness_report.html").exists()
    assert {"aurora", "lumen", "voltix"} <= set(data)          # existing brands still run


def test_bad_config_fails_at_load(ws):
    import pytest
    (ws / "config/vendors/zenpack.yaml").write_text(VENDOR.replace("material_type: [\"Mat\"]", "materiel: [\"Mat\"]"))
    with pytest.raises(Exception):
        load_config(ws / "config")
    (ws / "config/vendors/zenpack.yaml").write_text(VENDOR.replace("GBP", "ZZZ"))
    with pytest.raises(Exception):
        load_config(ws / "config")
