import pytest

from src.analysis import analyze_brand, assert_single_brand


def test_curated_and_tables_hold_one_brand(built):
    _, data = built
    for b, bd in data.items():
        for rows in (bd.curated, bd.candidates, bd.rejects, bd.violations, bd.conflicts, bd.review):
            assert all(r["brand_id"] == b for r in rows)


def test_leak_guard_trips(cfg, built):
    _, data = built
    a = analyze_brand(cfg, data["aurora"])
    a["tables"] = {k: list(v) for k, v in a["tables"].items()}   # do not mutate the shared fixture
    a["tables"]["violations"].append({"brand_id": "lumen", "sku": "X"})
    with pytest.raises(AssertionError):
        assert_single_brand(a)


def test_per_brand_reports_do_not_mention_other_brands(built):
    root, data = built
    skus = {b: {r["sku"] for r in bd.curated} for b, bd in data.items()}
    names = {"aurora": "Aurora", "lumen": "Lumen", "voltix": "Voltix"}
    for b in data:
        text = (root / "reports" / b / "readiness_report.html").read_text(encoding="utf-8")
        for other in data:
            if other != b:
                assert names[other] not in text
                assert not any(s in text for s in skus[other])


def test_consolidated_is_aggregate_only(built):
    import pandas as pd
    root, data = built
    df = pd.read_csv(root / "reports/_consolidated/benchmark.csv")
    assert len(df) == len(data)
    assert not {"sku", "vendor_id", "source_file", "source_row"} & set(df.columns)
