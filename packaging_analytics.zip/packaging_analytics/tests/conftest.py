import shutil
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parents[1]


def make_workspace(dst: Path) -> Path:
    """Copy config + raw sample data into a scratch dir so tests never touch the repo's outputs."""
    shutil.copytree(REPO / "config", dst / "config")
    shutil.copytree(REPO / "data/raw", dst / "data/raw")
    return dst


@pytest.fixture()
def ws(tmp_path):
    return make_workspace(tmp_path)


@pytest.fixture(scope="session")
def built(tmp_path_factory):
    from src.pipeline import run
    root = make_workspace(tmp_path_factory.mktemp("ws"))
    data = run("config", root, stage="report")
    return root, data


@pytest.fixture(scope="session")
def cfg():
    from src.config import load_config
    return load_config(REPO / "config")
