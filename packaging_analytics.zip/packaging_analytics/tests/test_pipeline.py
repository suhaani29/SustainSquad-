import csv
import re
from collections import Counter
from datetime import date

import pytest

from src.config import load_config
from src.ingest import get_adapter
from src.normalize.normalizer import normalize_table
from src.pipeline import run
from src.readiness.score import readiness
from src.validate.survivorship import survive


def raw_rows(cfg, root, brand, vendor):
    v = cfg.vendors[vendor]
    p = root / v.source.path_pattern.format(brand=brand)
    return get_adapter(v.source.format).read(v, p, str(p.relative_to(root))), p


def test_every_violation_traces_to_a_source_row(cfg, built):
    root, data = built
    for b, bd in data.items():
        assert bd.violations
        for v in bd.violations:
            table, _ = raw_rows(cfg, root, b, v["vendor_id"])
            row = next(r for r in table.rows if r["_source_row"] == v["source_row"])
            assert v["source_file"] == table.source_file and row  # row exists in the raw file


def test_rejects_have_reason_codes_and_lineage(built):
    _, data = built
    codes = Counter()
    for bd in data.values():
        for r in bd.rejects:
            assert r["reason_code"] and r["source_file"] and r["source_row"]
            codes[r["reason_code"]] += 1
    assert {"MISSING_SKU", "NON_NUMERIC_VALUE", "UNKNOWN_CURRENCY", "DUPLICATE_IN_SOURCE", "OUT_OF_RANGE"} <= set(codes)
    assert any(c.startswith("UNMAPPED_") for c in codes)


def test_nothing_dropped_silently(cfg, built):
    """raw rows = normalized records + normalize rejects (schema rejects come out of the normalized set)."""
    _, data = built
    for bd in data.values():
        n_raw = sum(v.n_raw for v in bd.vendor_stats)
        rej_rows = {(r["vendor_id"], r["source_row"]) for r in bd.rejects}
        ok_rows = {(r["vendor_id"], r["source_row"]) for r in bd.candidates}
        assert len(rej_rows | ok_rows) == n_raw and not (rej_rows & ok_rows)


def test_extras_preserve_unmapped_columns(built):
    _, data = built
    assert any(r["extras"] for r in data["aurora"].candidates)
    assert any("Lagerort" in r["extras"] for r in data["lumen"].candidates if r["vendor_id"] == "nordpack")


def test_fuzzy_below_threshold_goes_to_review_not_applied(cfg, built):
    _, data = built
    for bd in data.values():
        pend = [r for r in bd.review if r["status"] == "pending_review"]
        assert pend
        th = cfg.brands[bd.brand_id].thresholds.fuzzy_auto_apply
        assert all(r["confidence"] < th for r in pend)
        assert all(r["confidence"] >= th for r in bd.review if r["status"] == "auto_applied")
        rejected = {(r["vendor_id"], r["source_row"]) for r in bd.rejects}
        assert all((r["vendor_id"], r["source_row"]) in rejected for r in pend)   # never silently applied


def test_brand_threshold_override_changes_fuzzy_outcome(cfg, ws):
    """lumen auto-applies at 0.92, a stricter brand would not: same data, config-only difference."""
    table, _ = raw_rows(cfg, ws, "lumen", "andes_sourcing")
    loose = normalize_table(cfg, "lumen", "andes_sourcing", table, date(2026, 10, 26))
    cfg2 = cfg.model_copy(deep=True)
    cfg2.brands["lumen"].thresholds.fuzzy_auto_apply = 0.99
    strict = normalize_table(cfg2, "lumen", "andes_sourcing", table, date(2026, 10, 26))
    assert len(strict.records) < len(loose.records)


def rec(v, **kw):
    base = dict(brand_id="b", vendor_id=v, sku="S1", source_file=f"{v}.csv", source_row=1, product_category="x",
                material_type="PET", effective_from=date(2026, 1, 1), weight_g=10.0, unit_cost=1.0, recyclability=None)
    return base | kw


def test_survivorship_strategies(cfg):
    brand = cfg.brands["aurora"].model_copy(deep=True)
    a, b = rec("a", effective_from=date(2026, 1, 1)), rec("b", effective_from=date(2026, 6, 1), weight_g=20.0)
    brand.survivorship, brand.preferred_vendors = ["preferred_vendor"], ["a", "b"]
    assert survive([a, b], brand, cfg.schema_)[0]["vendor_id"] == "a"
    brand.survivorship = ["most_recent"]
    cur, info, conflicts = survive([a, b], brand, cfg.schema_)
    assert cur["vendor_id"] == "b" and info["decided_by"] == "most_recent"
    assert [c["field"] for c in conflicts] == ["weight_g"]
    brand.survivorship = ["highest_completeness"]
    assert survive([a, rec("b", recyclability="recyclable")], brand, cfg.schema_)[0]["vendor_id"] == "b"
    # chain: most_recent ties -> preferred_vendor decides
    brand.survivorship, brand.preferred_vendors = ["most_recent", "preferred_vendor"], ["b"]
    assert survive([a, rec("b")], brand, cfg.schema_)[1]["decided_by"] == "preferred_vendor"


def test_fill_nulls_from_losers_flag(cfg):
    brand = cfg.brands["aurora"].model_copy(deep=True)
    brand.survivorship, brand.preferred_vendors = ["preferred_vendor"], ["a"]
    a, b = rec("a"), rec("b", recyclability="recyclable")
    brand.fill_nulls_from_losers = True
    cur, info, _ = survive([a, b], brand, cfg.schema_)
    assert cur["recyclability"] == "recyclable" and info["filled_from"] == {"recyclability": "b"}
    brand.fill_nulls_from_losers = False
    assert survive([a, b], brand, cfg.schema_)[0]["recyclability"] is None


def test_same_sku_across_vendors_reconciled_once(built):
    _, data = built
    for bd in data.values():
        skus = [r["sku"] for r in bd.curated]
        assert len(skus) == len(set(skus))
        multi = [s for s in bd.survivorship if len(s["candidates"]) > 1]
        assert multi and all(s["lineage"] and s["decided_by"] for s in multi)


def test_readiness_reproducible_and_hand_checkable(cfg, built):
    _, data = built
    bd = data["lumen"]
    a, b = readiness(cfg, bd), readiness(cfg, bd)
    assert a == b
    w = cfg.readiness_weights("lumen")
    assert w["api_edi_availability"] == 0.10 and w["traceability"] == 0.20   # brand override applied
    manual = sum(w[k] * v["score"] for k, v in a["dimensions"].items()) / sum(w.values())
    assert a["score"] == pytest.approx(manual, abs=0.06)
    flat = readiness(cfg, bd, {k: 1.0 for k in w})
    assert flat["score"] != a["score"]                                      # weights really drive the score


def test_pipeline_idempotent(ws):
    run("config", ws, stage="report")
    first = {p: p.read_bytes() for p in (ws / "data/curated").rglob("*.csv")}
    second_run = run("config", ws, stage="report")
    assert first and all(p.read_bytes() == b for p, b in first.items())
    assert second_run


def test_single_vendor_and_stage_flags(ws):
    run("config", ws, brands=["aurora"], vendors=["nordpack"], stage="normalize")
    assert (ws / "data/staged/aurora/nordpack.json").exists()
    assert not (ws / "data/staged/aurora/pacificflex.json").exists() and not (ws / "data/curated").exists()
