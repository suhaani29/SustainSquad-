from src.config import RuleDef
from src.validate.rules import apply_op, evaluate, select_rules


def rule(**kw):
    base = dict(rule_id="R", rule_version=1, scope={}, severity="error", when={}, message="m", assert_=[])
    base.update(kw)
    base["assert"] = base.pop("assert_")
    return RuleDef.model_validate(base)


def test_ops():
    assert apply_op("between", 2, [1, 3]) and not apply_op("between", 4, [1, 3])
    assert apply_op("contains_any", ["EPR"], ["EPR", "PPWR"]) and not apply_op("contains_any", [], ["EPR"])
    assert apply_op("not_in", "A", ["B"]) and apply_op("regex", "AB-12", r"^[A-Z]{2}-\d+$")
    assert apply_op("required", "x", None) and not apply_op("required", None, None)


def test_rule_in_isolation(cfg):
    r = rule(when={"packaging_level": "primary", "food_contact": True},
             assert_=[{"field": "recycled_content_pct", "op": "<=", "value": 30}, {"field": "material_type", "op": "not_in", "value": ["PVC"]}])
    bad = {"packaging_level": "primary", "food_contact": True, "recycled_content_pct": 40, "material_type": "PVC"}
    v = evaluate(r, bad, cfg.taxonomy)
    assert v and {f["field"] for f in v["failed"]} == {"recycled_content_pct", "material_type"}
    assert evaluate(r, {**bad, "food_contact": False}, cfg.taxonomy) is None      # `when` not met
    assert evaluate(r, {**bad, "recycled_content_pct": None, "material_type": "PET"}, cfg.taxonomy) is None  # null skips


def test_derived_field_rule(cfg):
    r = rule(assert_=[{"field": "density_g_cm3", "op": "between", "value": [0.0005, 3]}])
    ok = {"length_mm": 100, "width_mm": 100, "height_mm": 100, "weight_g": 50}
    assert evaluate(r, ok, cfg.taxonomy) is None
    assert evaluate(r, {**ok, "weight_g": 50000}, cfg.taxonomy) is not None


def test_precedence_most_specific_wins(cfg):
    pick = lambda cat, b, v, reg: {r.rule_id: r for r in select_rules(cfg.rules, cat, b, v, reg)}  # noqa: E731
    assert pick("food_beverage", "aurora", "nordpack", "EU")["FOOD_CONTACT_RECYCLED_CAP"].rule_version == 2   # brand+region
    assert pick("food_beverage", "lumen", "nordpack", "EU")["FOOD_CONTACT_RECYCLED_CAP"].rule_version == 1
    assert pick("food_beverage", "aurora", "nordpack", "US")["FOOD_CONTACT_RECYCLED_CAP"].rule_version == 1
    assert "FOOD_CONTACT_RECYCLED_CAP" not in pick("food_beverage", "aurora", "nordpack", "IN")
    assert "FOOD_CONTACT_RECYCLED_CAP" not in pick("electronics", "aurora", "nordpack", "EU")


def test_vendor_scope_beats_brand_and_disable_works():
    base = rule(rule_id="X", scope={"category": "a"}, assert_=[{"field": "weight_g", "op": ">", "value": 1}])
    brand = rule(rule_id="X", rule_version=1, scope={"category": "a", "brand": "b1"}, assert_=[{"field": "weight_g", "op": ">", "value": 2}])
    vend = rule(rule_id="X", rule_version=1, scope={"vendor": "v1"}, enabled=False, assert_=[{"field": "weight_g", "op": ">", "value": 3}])
    got = select_rules([base, brand, vend], "a", "b1", "v9", None)
    assert got[0].assert_[0].value == 2
    assert select_rules([base, brand, vend], "a", "b1", "v1", None) == []   # vendor override disables it
    v2 = rule(rule_id="Y", rule_version=2, assert_=[{"field": "weight_g", "op": ">", "value": 1}])
    v1 = rule(rule_id="Y", rule_version=1, assert_=[{"field": "weight_g", "op": ">", "value": 9}])
    assert select_rules([v1, v2], None, "b", "v", None)[0].rule_version == 2   # same scope: higher version
