from datetime import date

import pytest

from src.normalize.currency import UnknownCurrency, convert
from src.normalize.units import to_g, to_mm


def test_units():
    assert to_mm(1, "in") == 25.4 and to_mm(2, "cm") == 20 and to_mm(3, "mm") == 3
    assert to_g(1, "kg") == 1000 and to_g(1, "lb") == pytest.approx(453.59237) and to_g(1, "oz") == pytest.approx(28.3495, rel=1e-4)


def test_currency_uses_rate_table(cfg):
    r = cfg.rates.to_usd
    assert convert(100, "EUR", "USD", r) == pytest.approx(108)
    assert convert(100, "INR", "EUR", r) == pytest.approx(100 * 0.0119 / 1.08)
    with pytest.raises(UnknownCurrency):
        convert(1, "XXX", "USD", r)


def test_end_to_end_conversion(built):
    """Vendor rows arrive in oz / kg / cm and INR / EUR / USD; curated is always g / mm and the brand currency."""
    _, data = built
    aur = {(r["vendor_id"], r["sku"]): r for r in data["aurora"].candidates}
    pf = next(r for (v, _), r in aur.items() if v == "pacificflex")
    assert pf["currency"] == "USD" and pf["src_currency"] == "USD"
    # weights in grams: pacificflex is oz, nordpack kg, andes g -> same order of magnitude after normalising
    import statistics
    ws = [r["weight_g"] for r in data["aurora"].candidates if r.get("weight_g") is not None]
    assert min(ws) >= 0.01 and statistics.median(ws) < 500      # plausible grams; seeded outliers are caught by DENSITY_PLAUSIBLE
    nord_eur = [r for r in data["voltix"].candidates if r["vendor_id"] == "nordpack"][0]
    assert nord_eur["currency"] == "INR" and nord_eur["src_currency"] in {"EUR", "USD", "INR"}
    assert nord_eur["unit_cost"] == pytest.approx(
        convert(nord_eur["src_unit_cost"], nord_eur["src_currency"], "INR", {"EUR": 1.08, "USD": 1.0, "INR": 0.0119}), rel=1e-4)
    assert nord_eur["fx_as_of"] == "2026-09-30"
